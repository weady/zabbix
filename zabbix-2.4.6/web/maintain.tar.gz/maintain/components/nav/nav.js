var Nav = {
	url:[
		"hostdetail_cpu.html?",
		"hostdetail_mem.html?",
		"hostdetail_disk.html?",
		"hostdetail_network.html?",
		"hostdetail_service.html?"
	],
	init:function (id,name) {
		$('.headnav a').click(function(){
			var index = $(this).index();
			window.location.href = Nav.url[index]+"hostid="+id+"&name="+name;
		});
	}
}