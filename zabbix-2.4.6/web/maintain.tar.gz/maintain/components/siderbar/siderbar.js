var SiderBar = {
	$menus:$('.siderbar-menu'),
	$target:$('.content'),
	$siderbar:$('.siderbar'),
	$togglesiderbar:$('.toggle-siderbar'),
	$targetwrap:$('.content-wrap'),
	bindEvent:function(){
		// 切换页面
		SiderBar.$menus.click(function(){

			var $self = $(this);
			var location = $self.data('location');

			SiderBar.$target.attr('src',location);
			SiderBar.$menus.removeClass('siderbar-menu-active');
			$self.addClass('siderbar-menu-active');

		});

		// 缩略菜单
		SiderBar.$togglesiderbar.click(function(){

			if(SiderBar.$siderbar.hasClass('siderbar-toggled')){

				SiderBar.$targetwrap.css({marginLeft:"210px"});
				SiderBar.$siderbar.removeClass('siderbar-toggled');

			}else{

				SiderBar.$targetwrap.animate({marginLeft:"55px"},500);
				SiderBar.$siderbar.addClass('siderbar-toggled');

			}

		});
	}
}

;(function ($,window) {
	SiderBar.bindEvent();
})(jQuery,Window);