function checkLogin(callback){
    var accesstoken = $.cookie("token");

    if(accesstoken != null){
        return true;
    }else{
        window.location.href="login.html"
    }
}
var Error = {
    getData : function () {
        var param0 = new Object();
        param0.search = {
            key_:'baseinfo[alert_info]'
        };
        param0.application = '主机的基础信息';

        //通过Zabbix服务发送请求
        ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
            var result = data.result[0].lastvalue.split('#');
            var errorData = new Array();

            for (var i = 0; i < result.length-1; i++) {
                var error = new Object();
                error.clock = result[i].split('|')[0];
                error.errorInfo = result[i].split('|')[1];
                error.host = result[i].split('|')[2];
                error.level = result[i].split('|')[3];

                errorData.push(error);
            }
            // 添加节点数据
            $('#errorNum').html(errorData.length);

            var preerrornum = $.cookie('errornum');
            
            if(preerrornum<errorData.length){
                ion.sound.play("4");
            }

            $.cookie('errornum',errorData.length);
        }, function(data){
            //token不存在，返回登录
            goToLogin();

        })
    }
}

;(function($,window){
    checkLogin();
    Error.getData();

    ion.sound({
        sounds: [
            {name: "4"}
        ],
        path:'components/sound/',
        preload: true,
        volume: 1.0
    });
    ion.sound.play("4");
    window.setInterval(function(){
    	Error.getData();
    },10000);
})(jQuery,window);