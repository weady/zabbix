// 获取hostid
var HOSTID = window.location.search.split('&')[0].split('=')[1];

var DataObject = [{
	title:'TPS每秒事务数',
	selector:'#tps',
	history:3,
	key:'mysql.monitor[TPS]',
	duration:15,
	durationunit:'minutes'
},{
	title:'QPS每秒事务数',
	selector:'#qps',
	history:3,
	key:'mysql.monitor[mysqlstatus_Questions]',
	duration:15,
	durationunit:'minutes'
},{
	title:'慢查询率',
	selector:'#slowquery',
	history:0,
	key:'mysql.monitor[Slow_queries_ratio]',
	duration:15,
	durationunit:'minutes'
},{
	title:'Thread Cache 命中率',
	selector:'#cache_ratio',
	history:0,
	key:'mysql.monitor[Thread_cache_ratio]',
	duration:15,
	durationunit:'minutes'
},{
	title:'InnoDB缓冲池的读命中率',
	selector:'#Innodb_buffer_read_ratio',
	history:0,
	key:'mysql.monitor[Innodb_buffer_read_ratio]',
	duration:15,
	durationunit:'minutes'
},{
	title:'Query Cache命中率',
	selector:'#Query_cache_ratio',
	history:0,
	key:'mysql.monitor[Query_cache_ratio]',
	duration:15,
	durationunit:'minutes'
},{
	title:'缓存利用率',
	selector:'#cache_used_ratio',
	history:0,
	key:'mysql.monitor[cache_used_ratio]',
	duration:15,
	durationunit:'minutes'
},{
	title:'Innodb缓冲池的利用率',
	selector:'#Innodb_buffer_pages_used_ratio',
	history:0,
	key:'mysql.monitor[Innodb_buffer_pages_used_ratio]',
	duration:15,
	durationunit:'minutes'
},{
	title:'索引命中率',
	selector:'#Key_buffer_read_ratio',
	history:0,
	key:'mysql.monitor[Key_buffer_read_ratio]',
	duration:15,
	durationunit:'minutes'
},{
	title:'失败的连接数',
	selector:'#mysqlstatus_Aborted_connects',
	history:3,
	key:'mysql.monitor[mysqlstatus_Aborted_connects]',
	duration:15,
	durationunit:'minutes'
},{
	title:'当前连接线程数',
	selector:'#mysqlstatus_threads_connected',
	history:3,
	key:'mysql.monitor[mysqlstatus_threads_connected]',
	duration:15,
	durationunit:'minutes'
},{
	title:'当前运行线程数',
	selector:'#mysqlstatus_Threads_running',
	history:3,
	key:'mysql.monitor[mysqlstatus_Threads_running]',
	duration:15,
	durationunit:'minutes'
},{
	title:'当前打开的表数量',
	selector:'#mysqlstatus_open_tables',
	history:3,
	key:'mysql.monitor[mysqlstatus_open_tables]',
	duration:15,
	durationunit:'minutes'
},{
	title:'当前打开文件的数量',
	selector:'#mysqlstatus_open_files',
	history:3,
	key:'mysql.monitor[mysqlstatus_open_files]',
	duration:15,
	durationunit:'minutes'
},{
	title:'每秒慢查询操作数',
	selector:'#mysqlstatus_Slow_queries',
	history:3,
	key:'mysql.monitor[mysqlstatus_Slow_queries]',
	duration:15,
	durationunit:'minutes'
}];


var DBDetail = {
	getbaseInfo:function () {

		var param0 = new Object();

		param0.search = {
			'key_' : 'zabbix.data[get_mysql_info]'
		}

		ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
			
			var result = data.result;

			for(var i = 0; i < result.length ; i++){

				if(result[i].templateid != '0'){

					var resultArray = result[i].lastvalue.split('#');

				}

			}

			for (var i = 0; i < resultArray.length-1; i++) {
				
				var temp = resultArray[i].split('|');

				if(temp[0]== HOSTID){

					var datebaseObject = {

						// 主机id
						hostid:temp[0],
						// 主机名
						hostname:temp[1],
						// 主机ip
						hostip:temp[2],
						// 主从关系
						m_s_relation:temp[3],
						// 主从状态
						m_s_status:temp[4],
						// Master_Host
						masterhost:temp[5],
						// 二进制日志
						bin_log:temp[6],
						// Postion
						position:temp[7],
						// Read_Master_log_pos
						read_log_pos:temp[8],
						// Exec_Master_log_pos
						exec_log_pos:temp[9],
						// 主从延迟
						m_s_delay:temp[10],
						// 连接数
						con_count:temp[11],
						// 数据库数量
						db_count:temp[12]

					}
				}

			}

			$('.hostname').html(datebaseObject.hostname);
			$('#hostip').html(datebaseObject.hostip);
			$('#m_s_relation').html(datebaseObject.m_s_relation);
			$('#m_s_status').html(datebaseObject.m_s_status);
			$('#masterhost').html(datebaseObject.masterhost);
			$('#bin_log').html(datebaseObject.bin_log);
			$('#position').html(datebaseObject.position);
			$('#read_log_pos').html(datebaseObject.read_log_pos);
			$('#exec_log_pos').html(datebaseObject.exec_log_pos);
			$('#m_s_delay').html(datebaseObject.m_s_delay);
			$('#con_count').html(datebaseObject.con_count);
			$('#db_count').html(datebaseObject.db_count);

		}, function(data){
		    //token不存在，返回登录
		    goToLogin(DatabaseList);

		});
	},
	/**
	 * 获取历史数据并绘图
	 * @param  {string} key      键值
	 * @param  {number} history  指定数据类型
	 * @param  {string} selector 指定绘制图表的选择器
	 * @return {[type]}          [description]
	 */
	getData:function(key,selector,title,duration,durationunit){
		var param0 = new Object();
		param0.search = {
			key_:key
		};
		param0.hostids = HOSTID;

		ZabbixServer.sendAjaxRequest('item.get',param0,function(dataforitem){
			var itemid = dataforitem.result[0].itemid;

			var param = new Object();
			param.history = dataforitem.result[0].value_type;
			param.itemids = itemid;
			param.time_from = moment().add(-duration,durationunit).format('X');
			param.time_till = moment().format('X');
			param.limit ='';

			ZabbixServer.sendAjaxRequest('history.get',param,function(data){

				var result = data.result;

				var dataArray = new Array();
				for (var i = 0; i < result.length; i++) {
					dataArray.push([parseInt(result[i].clock) * 1000, parseInt(result[i].value)]);
				}

				DBDetail.render(selector,title,dataArray);

			});
		});
		
	},
	render:function(selector,title, dataArray){
		Highcharts.setOptions({
		    global: {
		        useUTC: false
		    }
		});

		$(selector).highcharts({
		    credits: {
		        text: '',
		        href: '',
		        enabled: false 
		    },
		    chart: {
		        zoomType: 'x',
		        backgroundColor:"#EDF2F8"
		    },
		    colors:["#E87F69","#9020CB"],
		    title: {
		        text: ''
		    },
		    xAxis: {
		        labels: {  
		            formatter: function() {  
		                var vDate=moment(this.value);  
		                return (vDate.format('HH:mm'));  
		            }
		        },
		        title: {
		            text: null
		        }
		    },
		    yAxis: {
		        title:{
		            text:''
		        }
		    },
		    tooltip: {
		        formatter:function(){
		            return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+'：<b>' +this.y +'</b>';
		        }
		    },
		    legend: {
		        enabled: false
		    },
		    plotOptions: {
		        line: {
		            lineWidth: 1,
		            marker: {
		                enabled: false
		            },
		            shadow: false,
		            states: {
		                hover: {
		                    lineWidth: 1
		                }
		            }
		        }
		    },

		    series: [{
		        type:'line',
		        name: title,
		        data: dataArray
		    }]
		}); 
	}
}

;(function(){

	DBDetail.getbaseInfo();

	for (var i = 0; i < DataObject.length; i++) {
		DBDetail.getData(DataObject[i].key,DataObject[i].selector,DataObject[i].title,DataObject[i].duration,DataObject[i].durationunit);
	}

})();