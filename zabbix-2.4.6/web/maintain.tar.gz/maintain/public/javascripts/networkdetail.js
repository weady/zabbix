// 获取hostid
var HOSTID = window.location.search.split('&')[0].split('=')[1];
var HOSTNAME = window.location.search.split('&')[1].split('=')[1];
// 初始化导航条
Nav.init(HOSTID,HOSTNAME);
$('.hostname').html(HOSTNAME);

var Network = {
	// 初始化
	init:function(){
		var param0 = {
			hostids:HOSTID,
			application:'网卡流量和状态'
		}

		ZabbixServer.sendAjaxRequest('item.get',param0,function(data){
			var result = data.result;
			var emList = new Array();
			var ipstring = '',
				macstring = '';

			for (var i = 0; i < result.length; i++) {
				
				// 获取ip地址未拆分的字符串
				if(result[i].key_ == 'baseinfo[ip_list]'){
					ipstring = result[i].lastvalue;
				}

				// 获取mac地址未拆分的字符串
				if(result[i].key_ == 'system.hw.macaddr'){
					macstring = result[i].lastvalue;
				}
			}

			// 拆分ip地址，获取mac个数
			var ipArray = ipstring.split('|');
			var macArray = macstring.split(',');

			// 处理结果将数据push到网卡数组中
			for (var i = 0; i < ipArray.length-1; i++) {
				var em = new Object();
				em.name = ipArray[i].split(' ')[0];
				em.ipaddr = ipArray[i].split(' ')[1];
				em.macaddr = macArray[i].split(']')[1];

				emList.push(em);
			}

			// 生成DOM
			Network.addDom(emList);

		},function(){
			//token不存在，返回登录
		    goToLogin();
		});
	},
	addDom:function(emList){
		var domLength = emList.length;				// 绘制节点的个数
		var oddFlag = domLength%2 == 0? 1 : 0;		// 能否被2整除
		var rowLength = Math.ceil(domLength/2);		//由于每两个节点在bootstrap中为一行，所以计算row的个数

		var dom = '<div class="row" style="margin-top: 50px;">' +
			            '<div class="col-md-6" >' +
			                '<div class="databoard">' +
			                    '<h1 class="datatitle">'+
			                    	'<span class="emName"></span>'+
			                    	'<span class="titlelabel macAddr"></span>'+
			                    	'<span class="titlelabel ipAddr"></span>'+
			                    '</h1>' +
			                    '<div class="dataChart">' +
			                    '</div>' +
			                '</div>' +
			            '</div>' +
			            '<div class="col-md-6" >' +
			                '<div class="databoard">' +
			                    '<h1 class="datatitle">'+
			                    	'<span class="emName"></span>'+
			                    	'<span class="titlelabel macAddr"></span>'+
			                    	'<span class="titlelabel ipAddr"></span>'+
			                    '</h1>' +
			                    '<div class="dataChart">' +
			                    '</div>' +
			                '</div>' +
			            '</div>' +
			        '</div>';
		// 添加row
		for (var i = 0; i < rowLength; i++) {
			if(i == rowLength-1){
				//如果不能被2整除
				if(!oddFlag){
					dom = '<div class="row" style="margin-top: 50px;">' +
			            '<div class="col-md-6" >' +
			                '<div class="databoard">' +
			                    '<h1 class="datatitle">'+
			                    	'<span class="emName"></span>'+
			                    	'<span class="titlelabel macAddr"></span>'+
			                    	'<span class="titlelabel ipAddr"></span>'+
			                    '</h1>' +
			                    '<div class="dataChart">' +
			                    '</div>' +
			                '</div>' +
			            '</div>' +
			        '</div>';
				}
			}
			$('.main').append(dom);
		}
		
		$('.datatitle').each(function(index,element){
			var $this = $(this);
			$this.find('.emName').html(emList[index].name);
			$this.find('.macAddr').html('mac:'+emList[index].macaddr);
            $this.find('.ipAddr').html('ip:'+emList[index].ipaddr);
			$this.next('.dataChart').attr("id", emList[index].name);
		});


		for (var i = 0; i < emList.length; i++) {
            dateRangePicker[emList[i].name] = {};
            dateRangePicker[emList[i].name].getData = Network.getData;
			dateRangePicker[emList[i].name].getData(emList[i], i);
		}

	},
	// 获取各网卡的数据
	getData: function(em,emindex){
        var _this = this;
        // 缓存参数
        dateRangePicker.argsCache(em.name, {em: em, emindex: emindex});
        em      = _this.argsCache.em;
        emindex = _this.argsCache.emindex;

        dateRangePicker.init(em.name);

		var param0 = new Object();
            param0.application = "网卡流量和状态";
            param0.hostids = HOSTID;

        var inkey = 'net.if.in['+em.name+']';
        var outkey = 'net.if.out['+em.name+']';

        //通过Zabbix服务发送请求
        ZabbixServer.sendAjaxRequest("item.get", param0, function(data) {
            // 对比key_值,获得itemid
            var iTemData = data.result;
            var Items = new Object();

            for (var i = 0; i < iTemData.length; i++) {

                // 读速率
                if (iTemData[i].key_ == inkey) {
                    Items.inItem = iTemData[i].itemid;
                }

                // 写速率
                if (iTemData[i].key_ == outkey) {
                    Items.outItem = iTemData[i].itemid;
                }

            }

            var param1 = new Object();

            param1.itemids = [Items.inItem, Items.outItem];
            param1.hostids = HOSTID;
            param1.time_from = _this.fromUnix || moment().add(-15, 'minutes').format('X');
            param1.time_till = _this.toUnix || moment().format('X');
            param1.limit = '';

            var inData = new Array();
            var outData = new Array();

            // 获取history历史数据
            ZabbixServer.sendAjaxRequest(_this.methodType + ".get", param1, function(data) {

                var historyData = data.result;

                for (var i = 0; i < historyData.length; i++) {

                   
                    // 对比itemid 将数据push到对应的数组
                    if (historyData[i].itemid == Items.inItem) {
                        inData.push([parseInt(historyData[i].clock) * 1000, parseInt(historyData[i].value || historyData[i].value_avg)]);
                    }

                    if (historyData[i].itemid == Items.outItem) {
                        outData.push([parseInt(historyData[i].clock) * 1000, parseInt(historyData[i].value || historyData[i].value_avg)]);
                    }
                }

                var series = [inData, outData];

                Network.render(series,emindex);

            });
        });
	},
	// 绘制图形
	render:function(series,emindex){
		Highcharts.setOptions({
            global: {
                useUTC: false
            }
        });
        
        $('.dataChart').eq(emindex).highcharts({
            credits: {
                text: '',
                href: '',
                enabled: false 
            },
            chart: {
                zoomType: 'x',
                type:'line',
                backgroundColor:"#EDF2F8"
            },
            colors:["#00B8EA",'#F27D41'],
            title: {
                text: ''
            },
            xAxis: {
                labels: {  
                    formatter: function() {
                        var vDate=moment(this.value);
                        return (dateRangePicker["em" + (emindex + 1)].xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                    }
                },
                title: {
                    text: null
                }
            },
            yAxis: {
                title: {
                    text: ''
                },
                labels: {
                    formatter:function(){
                    	return GlobalUtil.getSize(this.value);
                    }
                }
            },
            tooltip: {
                formatter:function(){
                    return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+':<b>' + GlobalUtil.getSize(this.y)+'/s</b>';
                }
            },
            legend: {
                enabled: false
            },
            plotOptions: {
                line: {
                    lineWidth: 1,
                    marker: {
                        enabled: false
                    },
                    shadow: false,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    },
                }
            },

            series: [{
                type: 'line',
                name: '流入',
                data: series[0]
            },{
                type: 'line',
                name: '流出',
                data: series[1]
            }]
        });
	}
}

;(function ($,window) {
	// Network.init();
    dateRangePicker.Network = Network;
    dateRangePicker.Network.init();
})(jQuery,window);