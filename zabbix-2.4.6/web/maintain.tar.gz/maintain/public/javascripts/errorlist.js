var Error = {
	getData : function () {
		var param0 = new Object();
		param0.search = {
			key_:'baseinfo[alert_info]'
		};
		param0.application = '主机的基础信息';

		//通过Zabbix服务发送请求
		ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
		    var result = data.result[0].lastvalue.split('#');
		    var errorData = new Array();

		    for (var i = 0; i < result.length; i++) {
		    	var error = new Object();
		    	error.clock = result[i].split('|')[0];
		    	error.errorInfo = result[i].split('|')[1];
		    	error.host = result[i].split('|')[2];
		    	error.level = result[i].split('|')[4];
		    	error.hostid = result[i].split('|')[3];

		    	errorData.push(error);
		    }
		    // 添加节点数据
		    Error.addDom(errorData);

		}, function(data){
		    //token不存在，返回登录
		    goToLogin();

		})
	},
	addDom : function (data) {
		$('#errorList').find('tbody').children().remove();

		var dom = "";

		for (var i = 0; i < data.length-1; i++) {
			var href = 'hostdetail_cpu.html?id='+data[i].hostid+'&name='+data[i].host;
			dom += '<tr class="'+(data[i].level==='4'?'danger':'warning')+'">' +
		            	'<td>'+GlobalUtil.getLineNumber(i+1)+'</td>' +
		            	'<td>'+data[i].host+'</td>' +
		            	'<td>'+moment(data[i].clock*1000).format('YYYY年MM月DD日 HH:mm:ss')+'</td>' +
		            	'<td>'+data[i].errorInfo+'</td>' +
		            	'<td><a class="label label-danger" href="'+href+'">详情</a></td>' +
	        	'</tr>';
		}
		$('#errorList').find('tbody').append(dom);
	}
}

;(function(){
	Error.getData();
})();

