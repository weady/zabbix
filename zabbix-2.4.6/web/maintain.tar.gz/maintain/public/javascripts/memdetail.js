// 获取hostid
var HOSTID = window.location.search.split('&')[0].split('=')[1];
var HOSTNAME = window.location.search.split('&')[1].split('=')[1];
// 初始化导航条
Nav.init(HOSTID,HOSTNAME);
$('.hostname').html(HOSTNAME);

// 内存
var memPused = {
    // 获取数据
    getData: function (argument) {
        var _this = this;
        dateRangePicker.init("memPused");
        
        var param0 = {};

        param0.hostids = HOSTID;
        param0.application = "主机的内存状态";

        //通过Zabbix服务发送请求
        ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
            
            // 对比key_值,获得itemid
            var iTemData = data.result;
            var Items = new Object();

            for (var i = 0; i < iTemData.length; i++) {

                // 内存利用率
                if(iTemData[i].key_ == "mem.resource[pused]"){
                    Items.pusedItem = iTemData[i].itemid;
                }
                // 内存利用率TOP5
                if(iTemData[i].key_ == "baseinfo[mem_top5]"){
                    Items.memtop5Item = iTemData[i].itemid;
                }
            }

            var param1 = new Object();

            param1.itemids = [Items.pusedItem,Items.bufferItem];
            param1.hostids = HOSTID;
            param1[_this.methodType] = 0;
            param1.time_from = _this.fromUnix || moment().add(-15,'minutes').format('X');
            param1.time_till = _this.toUnix || moment().format('X');
            param1.limit = '';

            var pusedData = new Array(),
                memtop5Data = new Array();

            // 获取history历史数据
            ZabbixServer.sendAjaxRequest(_this.methodType + ".get", param1, function (data) {
               
               var historyData = data.result;

               for (var i = 0; i < historyData.length; i++) {
                    
                    // 对比itemid 将数据push到对应的数组
                    // 内存利用率
                    if(historyData[i].itemid == Items.pusedItem){
                        pusedData.push([parseInt(historyData[i].clock)*1000,parseInt(historyData[i].value || data.result[i].value_avg)]);
                    }
               }

               // 调用图形绘制器
               Chart.render('0',pusedData); 

            });

            var param2 = new Object();
            param2.itemids = [Items.memtop5Item] ;

            // 获取history历史数据
            ZabbixServer.sendAjaxRequest("item.get", param2, function (data) {
               
               var historyData = data.result;

               for (var i = 0; i < historyData.length; i++) {
                    
                    // 内存利用率TOP5
                    if(historyData[i].itemid == Items.memtop5Item){
                        memtop5Data.push(historyData[i].lastclock,historyData[i].lastvalue);
                    }

               }

               var series = memtop5Data;
               // 调用图形绘制器
               Chart.render('2',series);

            });
            
        }, function(data){

            //token不存在，返回登录
            goToLogin();

        });
    },
}
var bufferPused = {
    // 获取数据
    getData: function (argument) {
        var _this = this;
        dateRangePicker.init("bufferPused");
        
        var param0 = {};

        param0.hostids = HOSTID;
        param0.application = "主机的内存状态";

        //通过Zabbix服务发送请求
        ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
            
            // 对比key_值,获得itemid
            var iTemData = data.result;
            var Items = new Object();

            for (var i = 0; i < iTemData.length; i++) {

                // 内存空闲值
                if(iTemData[i].key_ == "mem.resource[memfree]"){
                    Items.bufferItem = iTemData[i].itemid;
                }
            }

            var param1 = new Object();

            param1.itemids = [Items.pusedItem,Items.bufferItem];
            param1.hostids = HOSTID;
            param1[_this.methodType] = 0;
            param1.time_from = _this.fromUnix || moment().add(-15,'minutes').format('X');
            param1.time_till = _this.toUnix || moment().format('X');
            param1.limit = '';

            var bufferData = new Array();

            // 获取history历史数据
            ZabbixServer.sendAjaxRequest(_this.methodType + ".get", param1, function (data) {
               
               var historyData = data.result;

               for (var i = 0; i < historyData.length; i++) {
                    
                    // 缓存利用率
                    if(historyData[i].itemid == Items.bufferItem){
                        bufferData.push([parseInt(historyData[i].clock)*1000,parseInt(historyData[i].value || historyData[i].value_avg)]);
                    }
               }

               // 调用图形绘制器
               Chart.render('1',bufferData);

            });
        }, function(data){

            //token不存在，返回登录
            goToLogin();

        });
    },
}

// 图形绘制器
var Chart = {
	/**
	 * 图形绘制函数
	 * @param  {string} type 图表标识 0:内存利用率 1:缓存利用率 2:内存利用率top5
	 * @return 图形绘制结果
	 */
	render:function(type,data){
		switch(type){
			case '0':Chart.drawMemPused(data);break;
			case '1':Chart.drawBufferPused(data);break;
			case '2':Chart.drawMemTop5(data);break;
		}

	},
	// 绘制内存利用率
	drawMemPused:function(series){
		Highcharts.setOptions({ global: { useUTC: false } });
		$('#memPused').highcharts({
            credits: {
                text: '',
                href: '',
                enabled: false 
            },
            chart: {
            	zoomType: 'x',
                type:'line',
                backgroundColor:"#EDF2F8"
            },
            colors:["#00B6E7"],
            title: {
                text: ''
            },
            xAxis: {
                labels: {  
                    formatter: function() {  
                        var vDate=moment(this.value);
                        return (dateRangePicker.memPused.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                    }
                },
                title: {
                    text: null
                }
            },
            yAxis: {
                title: {
                    text: ''
                },
                labels: {
	                format: '{value} %'
	            }
            },
            tooltip: {
                shared: true,
                formatter:function(){
                    return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>内存利用率：<b>' + this.y+'%</b>';
                }
            },
            legend: {
                enabled: false
            },
            plotOptions: {
                area: {
                    fillColor: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1},
                        stops: [
                            [0, "#00B6E7"],
                            [1, Highcharts.Color("#00B6E7").setOpacity(0).get('rgba')]
                        ]
                    },
                    lineWidth: 1,
                    marker: {
                        enabled: false
                    },
                    shadow: false,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    },
                }
            },
            series: [{
                type: 'area',
                name: 'value',
                data: series
            }]
        });            
	},
	// 绘制内存空闲值
	drawBufferPused:function (series) {
		Highcharts.setOptions({ global: { useUTC: false } });
		$('#bufferPused').highcharts({
            credits: {
                text: '',
                href: '',
                enabled: false 
            },
            chart: {
            	zoomType: 'x',
                type:'line',
                backgroundColor:"#EDF2F8"
            },
            colors:["#E8795F"],
            title: {
                text: ''
            },
            xAxis: {
                labels: {  
                    formatter: function() {  
                        var vDate=moment(this.value);
                        return (dateRangePicker.bufferPused.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                    }
                },
                title: {
                    text: null
                }
            },
            yAxis: {
                title: {
                    text: ''
                }
            },
            tooltip: {
                shared: true,
                formatter:function(){
                    return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>内存空闲值：<b>' + GlobalUtil.getSize(this.y)+'</b>';
                }
            },
            legend: {
                enabled: false
            },
            plotOptions: {
                area: {
                    fillColor: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1},
                        stops: [
                            [0, "#E8795F"],
                            [1, Highcharts.Color("#E8795F").setOpacity(0).get('rgba')]
                        ]
                    },
                    lineWidth: 1,
                    marker: {
                        enabled: false
                    },
                    shadow: false,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    },
                }
            },

            series: [{
                type: 'area',
                name: 'value',
                data: series
            }]
        }); 
	},
	// 绘制内存利用率Top5
	drawMemTop5:function (series) {
		var processes = new Array();
		var values = new Array();
		var temp = new Array();

		processes = series[1].split("|");

		for (var i = 0; i < processes.length; i++) {
			var process = new Object();

			process.value = processes[i].split(' ')[0];
			process.name = processes[i].split(' ')[1];

			temp.push(process);
		}

		$('.process').each(function(index,element){
			$(this).html(temp[index].name);
			$(this).next('.process-value').html(temp[index].value+ '%');
		});
	}
}

// ;(function(){
// 	Mem.getHistory();
// 	setInterval(function(){
		
// 		Mem.getHistory();
	
// 	},15000);
// })();

;(function() {
    dateRangePicker.memPused = memPused;
    dateRangePicker.bufferPused = bufferPused;

    dateRangePicker.memPused.getData();
    dateRangePicker.bufferPused.getData();

    // setInterval(function(){
    //     dateRangePicker.memPused.getData();
    //     dateRangePicker.bufferPused.getData();
    // },60000);
})();
