var ServiceList = {
	getData : function(){
		
		var param0 = new Object();

		param0.search = {
			'key_' : 'zabbix.data[get_homed_info]'
		}

		ZabbixServer.sendAjaxRequest('item.get',param0,function(data){

			var result = data.result;
			var serviceInfo = '';

			for (var i = 0; i < result.length; i++) {
				
				if(result[i].templateid != '0'){

					serviceInfo = result[i].lastvalue.split('#');

				}

			}

			var dom = '',
				domClass = '';

			for (var i = 0; i < serviceInfo.length-1; i++) {
				
				var serviceInfoArr = serviceInfo[i].split(' ');
				if(i==0){
					domClass = 'active';
					ServiceList.getHostInfo(serviceInfoArr[3],serviceInfoArr[0]);
					$('.servicename').html(serviceInfoArr[0]);
				}else{
					domClass = '';
				}
				if (serviceInfoArr[3] === '') {
					serviceInfoArr[2] = serviceInfoArr[1];
					serviceInfoArr[1] = 0;
				}
				dom += '<tr class="'+domClass+'" data-hostids="'+serviceInfoArr[3]+'">' +
						'<td>'+GlobalUtil.getLineNumber(i+1)+'</td>' +
						'<td>'+serviceInfoArr[0]+'</td>' +
						'<td>'+serviceInfoArr[1]+'</td>' +
						'<td>'+serviceInfoArr[2]+'</td>' +
					'</tr>';

			}

			$('#serviceList').find('tbody').append(dom)
		});

	},
	bindEvent : function(){
		$('#serviceList').on('click','tr',function(e){
			var $this = $(this),
				hostString = $this.data('hostids'),
				service = $this.find('td').eq(1).html();

			$('#serviceList').find('tr').removeClass('active');
			$(this).addClass('active');

			$('.servicename').html(service);
			ServiceList.getHostInfo(hostString,$.trim(service));
		});
	},
	getHostInfo : function(hostString,servicename){

		var hostids = hostString.split('|').slice(1);
		
		var param = {
			hostids:hostids
		}

		ZabbixServer.sendAjaxRequest('host.get',param,function(data){

			var hostData = data.result;

			var param0 = {
				hostids:hostids,
				search : {
					key_:'homed.status['+servicename+',status]'
				}
			}

			ZabbixServer.sendAjaxRequest('item.get',param0,function(data){
				
				// 获取了所有的hostname和id
				var hostArray = new Array(),
					serviceArray = new Array();

				for (var i = 0; i < hostData.length; i++) {
					var obj = new Object();

					obj.hostid = hostData[i].hostid;
					obj.hostname = hostData[i].host;

					hostArray.push(obj);
				}
				
				var data = data.result;

				for (var i = 0; i < data.length; i++) {
					
					var result = data[i].lastvalue.split('|').slice(1);
					if(!result[1]) continue;
					var statusString = result[1].split(' ')[1],
						serviceString = result[0];
					
					// 如果是db_writer服务和db_router
					if(servicename == 'db_router'||servicename == 'db_writer'){
						var services = serviceString.split('#');

						for (var j = 0; j < services.length-1; j++) {
							
							var serviceObj = new Object();

							serviceObj.hostid = data[i].hostid;
							serviceObj.servicenum = services[j];
							serviceObj.status = statusString;

							serviceArray.push(serviceObj);
						}

					}else{
						
						var serviceObj = new Object();

						serviceObj.hostid = data[i].hostid;
						serviceObj.servicenum = serviceString;
						serviceObj.status = statusString;

						serviceArray.push(serviceObj);
					}
				}

				var finalData = new Array();
				var obj = new Object();
				var dom='',count = 1;
				for (var k = 0; k < hostArray.length; k++) {
					
					for (var l = 0; l < serviceArray.length; l++) {
						
						if(hostArray[k].hostid == serviceArray[l].hostid){

							dom += '<tr>' +
								'<td class="text-center">'+GlobalUtil.getLineNumber(count)+'</td>' +
								'<td class="text-center">'+hostArray[k].hostname+'</td>' +
								'<td class="text-center">'+serviceArray[l].servicenum+'</td>' +
								'<td class="text-center">'+serviceArray[l].status+'</td>' +
								'<td class="text-center"><a class="label label-info" href="../views/platform_detail.html?hostid='+serviceArray[l].hostid+'&hostname='+hostArray[k].hostname+'&servicename='+servicename+'">查看</a></td>' +
							'</tr>';

							count++;
						}
						
					}

				}

				$('#serviceHost').find('tbody').children().remove();

				$('#serviceHost').find('tbody').append(dom);
				
			});
			
		});

	}
}

;(function(){
	
	ServiceList.getData();
	ServiceList.bindEvent();

})();