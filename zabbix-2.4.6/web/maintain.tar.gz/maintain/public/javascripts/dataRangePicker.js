var dateRangePicker = (function() {
    /**
     * 时间处理 在datepicker初始化及选择日期后调用
     * @param  {String} chartName 加载datepicker的对象名
     * @return {function}
     */
    var timeHandler = function(chartName) {
        return (function() {
            var fromUnix = $("[name='" + chartName + "_from']").val(),
                toUnix   = $("[name='" + chartName + "_to']").val(),
                fromNow  = parseInt((Date.parse(new Date())/1000 - (fromUnix || Date.parse(new Date())/1000))/86400),
                timeLast = parseInt((toUnix-fromUnix)/86400);
            if((timeLast > 0 && fromNow > 7) || (timeLast > 0 && fromNow < 8)) {
                dateRangePicker[chartName].methodType = "trends"; // 请求方式
                dateRangePicker[chartName].xAxisType = 2;         // x轴显示类型 1-时间 2-日期
            } else if(timeLast < 1 && fromNow > 7) {
                dateRangePicker[chartName].methodType = "trends";
                dateRangePicker[chartName].xAxisType = 1;
            } else if((timeLast < 1 && fromNow < 8) || true) {
                dateRangePicker[chartName].methodType = "history";
                dateRangePicker[chartName].xAxisType = 1;
            }
            dateRangePicker[chartName].fromUnix = fromUnix; // 起始日期
            dateRangePicker[chartName].toUnix = toUnix;     // 结束日期
            dateRangePicker[chartName].fromNow = fromNow;   // 起始日期距现在几天
            dateRangePicker[chartName].timeLast = timeLast; // 日期跨度
        })();
    }

    /**
     * 加载datepicker
     * @param  {String} chartName 加载datepicker的对象名
     */
    var datepicker = function(chartName) {
        timeHandler(chartName);
        var _this  = this;
        var $h1    = $("#" + chartName).prev();
        var html   = '\
            <div class="timepicker">\
                <input type="text" name="timepicker_' + chartName + '_from" placeholder="起始日期">\
                <input type="text" name="timepicker_' + chartName + '_to" placeholder="结束日期">\
                <input type="hidden" name="' + chartName + '_from">\
                <input type="hidden" name="' + chartName + '_to">\
            </div>';
        if($h1.find("div.timepicker").length > 0) return;
        if($h1.find("span").length > 1) {
            $(html).insertAfter($h1.find(">span:nth-child(2)")[0]);
            $h1.find("div.timepicker").css("position", "static");
        } else {
            $h1.append(html);
        }

        var ele          = {};
            ele.from     = $("[name='timepicker_" + chartName + "_from']");
            ele.to       = $("[name='timepicker_" + chartName + "_to']");
            ele.fromUnix = "[name='" + chartName + "_from']";
            ele.toUnix   = "[name='" + chartName + "_to']";
        
        var onClose = function(type, selectedDate) {
            var func = {
                comm: function(type) {
                    var dataType     = "maxDate",
                        thisUnixType = "fromUnix",
                        thatUnixType = "toUnix";
                    // 选择检测
                    !!selectedDate && (function(type) {
                        type == "to" && (function() {
                            dataType     = "minDate";
                            thisUnixType = "toUnix";
                            thatUnixType = "fromUnix";
                        })();
                        return true;
                    })(type) && 
                    // 重复检测
                    _this[chartName][thatUnixType] != $(ele[thatUnixType]).val() &&
                    _this[chartName][thatUnixType] != $(ele[thatUnixType]).val()/1000 + 86399 && (function() {
                        // 区间调整
                        // var dataArr = selectedDate.split("-");
                        // var day = parseInt(selectedDate.split("-")[2]);
                        // console.log()
                        // dataArr[2] = (day < 11 ? "0" : "") + (day + (type == "to" ? 1:-1));
                        // selectedDate = dataArr.join("-");
                        var dateBorder = moment(parseInt($(ele[thatUnixType]).val())).add((type == "to" ? 1:-1), "days").format("YYYY-MM-DD")
                        ele[type].datepicker("option", dataType, selectedDate);

                        $(ele.fromUnix).val() && 
                        $(ele.fromUnix).val().length > 10 && 
                        $(ele.fromUnix).val($(ele["fromUnix"]).val()/1000);

                        $(ele.toUnix).val() && 
                        $(ele.toUnix).val().length > 10 && 
                        $(ele.toUnix).val($(ele["toUnix"]).val()/1000 + 86399);

                        // 记录日期
                        _this[chartName][thisUnixType] = $(ele[thisUnixType]).val();
                        _this[chartName][thatUnixType] = $(ele[thatUnixType]).val();
                        timeHandler(chartName);

                        $(ele.fromUnix).val() && $(ele.toUnix).val() && (function() {
                            try {
                                _this[chartName].getData(chartName);
                            } catch(e) {
                                // 兼容旧写法
                                _this[chartName].getData.call(_this, chartName);
                            }
                        })();

                        return true;
                    })();

                },
                from: function() {
                    // 交叉传参
                    return this.comm("to");
                },
                to: function() {
                    return this.comm("from");
                }
            };

            func[type]();
        };

        var datepicker = function(type) {
            return (function() {
                ele[type].datepicker({
                    constrainInput: true,
                    changeMonth: true,
                    maxDate: 0,
                    altField: ele[type + "Unix"],
                    altFormat: "@",
                    showButtonPanel: false,
                    onClose: function(selectedDate) { onClose(type, selectedDate); }
                })
            })();
        };
        datepicker("from");
        datepicker("to");
    }

    /**
     * 参数缓存 用于缓存带参数的getData方法的参数
     * @param  {String} chartName 当前加载datepicker的对象名
     * @param  {Object} args      需要缓存的变量 { key: value, ...}
     */
    var argsCache = function(chartName, args) {
        // 不存在的对象名
        if (!dateRangePicker[chartName]) return;

        // 如果已缓存则拷贝缓存，然后更新缓存
        dateRangePicker[chartName].argsCache = dateRangePicker[chartName].argsCache || {};
        for(var i in args) {
            // 当getData方法由Datepicker回调时防止缓存的变量被错误改写
            if(args[i] === chartName) break;
            else if(args[i] !== undefined || args[i] !== null) dateRangePicker[chartName].argsCache[i] = args[i];
        }
    }

    return {
        init: datepicker,
        datepicker: datepicker, // 旧写法
        argsCache: argsCache
    };
})();