// 获取hostid
var HOSTID = window.location.search.split('&')[0].split('=')[1];
var HOSTNAME = window.location.search.split('&')[1].split('=')[1];
// 初始化导航条
Nav.init(HOSTID,HOSTNAME);
$('.hostname').html(HOSTNAME);

// CPU利用率
var CPUPused = {
	$ChartObj:$('#CPUPused'),			// 获取画表格的容器

	// 获取数据
	getData:function (argument) {
        var _this = this;
		dateRangePicker.init("CPUPused");
		var param0 = {};

		param0.hostids = HOSTID;
		param0.application = "CPU状态";

		//通过Zabbix服务发送请求
		ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
		    
			// 对比key_值,获得itemid
			var iTemData = data.result;
			var Items = new Object();

			for (var i = 0; i < iTemData.length; i++) {

				// cpu idle time
				if(iTemData[i].key_ == "system.cpu.util[,idle]"){
					Items.idleItem = iTemData[i].itemid;
				}

				// cpu user time
				if(iTemData[i].key_ == "system.cpu.util[,user]"){
					Items.userItem = iTemData[i].itemid;
				}

				// cpu system time
				if(iTemData[i].key_ == "system.cpu.util[,system]"){
					Items.systemItem = iTemData[i].itemid;
				}

				// cpu iowait time
				if(iTemData[i].key_ == "system.cpu.util[,iowait]"){
					Items.iowaitItem = iTemData[i].itemid;
				}

			}

			var param1 = new Object();

			param1.itemids = [Items.idleItem,Items.userItem,Items.systemItem,Items.iowaitItem];
			param1.hostids = HOSTID;
			param1[_this.methodType] = 0;
			param1.time_from = _this.fromUnix || moment().add(-20,'minutes').format('X');
			param1.time_till = _this.toUnix || moment().format('X');
			param1.limit = '';

			var idleTimeData = new Array(),
				idleTimeValues = new Array(),
				userTimeData = new Array(),
				userTimeValues = new Array(),
				systemTimeData = new Array(),
				systemTimeValues = new Array(),
				iowaitTimeData = new Array();
				iowaitTimeValues = new Array();

			// 获取history历史数据
			ZabbixServer.sendAjaxRequest(_this.methodType + ".get", param1, function (data) {
			   
			   var historyData = data.result;

			   for (var i = 0; i < historyData.length; i++) {
			   		
			   		// 对比itemid 将数据push到对应的数组
			   		if(historyData[i].itemid == Items.idleItem){
			   			idleTimeData.push([parseFloat(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
			   			idleTimeValues.push(parseFloat(historyData[i].value || historyData[i].value_avg));
			   		}

			   		if(historyData[i].itemid == Items.userItem){
			   			userTimeData.push([parseFloat(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
			   			userTimeValues.push(parseFloat(historyData[i].value || historyData[i].value_avg));
			   		}

			   		if(historyData[i].itemid == Items.systemItem){
			   			systemTimeData.push([parseFloat(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
			   			systemTimeValues.push(parseFloat(historyData[i].value || historyData[i].value_avg));
			   		}

			   		if(historyData[i].itemid == Items.iowaitItem){
			   			iowaitTimeData.push([parseFloat(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
			   			iowaitTimeValues.push(parseFloat(historyData[i].value || historyData[i].value_avg));
			   		}

			   }

			   var series = [idleTimeData,userTimeData,systemTimeData,iowaitTimeData];

			   // 赋值
			   //idletime 最新 最大 最小 平均
			   $('#idleNew').html(toFixed(idleTimeData[idleTimeData.length-1][1],2));
			   $('#idleMax').html(GlobalUtil.getMax(idleTimeValues)+"%");
			   $('#idleMin').html(GlobalUtil.getMin(idleTimeValues)+"%");
			   $('#idleAvg').html(GlobalUtil.getAverage(idleTimeValues)+"%");

			   $('#userNew').html(toFixed(userTimeData[userTimeData.length-1][1],2));
			   $('#userMax').html(GlobalUtil.getMax(userTimeValues)+"%");
			   $('#userMin').html(GlobalUtil.getMin(userTimeValues)+"%");
			   $('#userAvg').html(GlobalUtil.getAverage(userTimeValues)+"%");

			   $('#sysNew').html(toFixed(systemTimeData[systemTimeData.length-1][1],2));
			   $('#sysMax').html(GlobalUtil.getMax(systemTimeValues)+"%");
			   $('#sysMin').html(GlobalUtil.getMin(systemTimeValues)+"%");
			   $('#sysAvg').html(GlobalUtil.getAverage(systemTimeValues)+"%");

			   $('#ioNew').html(toFixed(iowaitTimeData[iowaitTimeData.length-1][1],2));
			   $('#ioMax').html(GlobalUtil.getMax(iowaitTimeValues)+"%");
			   $('#ioMin').html(GlobalUtil.getMin(iowaitTimeValues)+"%");
			   $('#ioAvg').html(GlobalUtil.getAverage(iowaitTimeValues)+"%");
			   // 绘图
			   CPUPused.render(series);

			});
			
		}, function(data){
		    
		    //token不存在，返回登录
		    goToLogin();

		});
	},
	// 绘图
	render:function(series){

		Highcharts.setOptions({ global: { useUTC: false } });
		CPUPused.$ChartObj.highcharts({
			title:{
				text:""
			},
			chart:{
				zoomType: 'x',
                type:'line',
                backgroundColor:"#EDF2F8"
            },
            colors:['#FF0000','#009BFF','#71CA00','#FFD300'],
			series:[{
				name:"idle time",
				data:series[0]
			},{
				name:"user time",
				data:series[1]
			},{
				name:"system time",
				data:series[2]
			},{
				name:"iowait time",
				data:series[3]
			}],
			xAxis: {
                labels: {  
                    formatter: function() {  
                        var vDate=moment(this.value);
                        return (dateRangePicker.CPUPused.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                    }
                },
                title: {
                    text: null
                }
        	},
        	yAxis:{
                tickInterval:10,
        		title: {
	                text: ''
	            },
	            labels: {
                    format: '{value} %'
                }
        	},
	        legend: {
	            enabled: false
	        },
	        tooltip: {
                formatter:function(){
                    return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+'：<b>' +Highcharts.numberFormat(this.y,2,'.') +'%</b>';
                }
            },
	        credits: {
			    enabled: false
			},
			plotOptions: {
                line: {
                    lineWidth: 1,
                    marker: {
                        enabled: false
                    },
                    shadow: false,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    }
                }
            }
		});

		$('#CPUPused').parent().find('.titlelabel').each(function(i,element){
			var colors=['#FF0000','#009BFF','#71CA00','#FFD300'];

			$(this).find('.glyphicon').css('color',colors[i]);
		});

	}
}
// CPU负载
var CPULoad = {
	// 获取数据
	getData : function(){
        var _this = this;
        dateRangePicker.init("CPULoad");
		// 设置参数
		var param0 = new Object();
			
		param0.hostids = HOSTID;
		param0.application = "CPU状态";

		//通过Zabbix服务发送请求
		ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
		    
			// 对比key_值,获得itemid
			var iTemData = data.result;
			var Items = new Object();

			for (var i = 0; i < iTemData.length; i++) {

				// 15 min 平均负载
				if(iTemData[i].key_ == "system.cpu.load[percpu,avg15]"){
					Items.load15 = iTemData[i].itemid;
				}

				// 5 min 平均负载
				if(iTemData[i].key_ == "system.cpu.load[percpu,avg5]"){
					Items.load5 = iTemData[i].itemid;
				}

				// 1 min 平均负载
				if(iTemData[i].key_ == "system.cpu.load[percpu,avg1]"){
					Items.load1 = iTemData[i].itemid;
				}

			}

			var param1 = new Object();

			param1.itemids = [Items.load15,Items.load5,Items.load1];
			param1.hostids = HOSTID;
			param1[_this.methodType] = 0;
			param1.time_from = _this.fromUnix || moment().add(-15,'minutes').format('X');
			param1.time_till = _this.toUnix || moment().format('X');
			param1.limit = '';

			var load15Data = new Array(),
				load5Data = new Array(),
				load1Data = new Array();

			// 获取history历史数据
			ZabbixServer.sendAjaxRequest(_this.methodType + ".get", param1, function (data) {
			   
			   var historyData = data.result;

			   for (var i = 0; i < historyData.length; i++) {
			   		
			   		// 对比itemid 将数据push到对应的数组
			   		if(historyData[i].itemid == Items.load15){
			   			load15Data.push([parseInt(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)])
			   		}

			   		if(historyData[i].itemid == Items.load5){
			   			load5Data.push([parseInt(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
			   		}

			   		if(historyData[i].itemid == Items.load1){
			   			load1Data.push([parseInt(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
			   		}

			   }

			   var series = [load15Data,load5Data,load1Data];

			   CPULoad.render(series);

			});
			
		}, function(data){
		    
		    //token不存在，返回登录
		    goToLogin();

		});
	},
	// 画图
	render:function(series){
		Highcharts.setOptions({ global: { useUTC: false } });
		$("#CPULoad").highcharts({
			title:{
				text:""
			},
			chart:{
				zoomType: 'x',
                type:'line',
                backgroundColor:"#EDF2F8"
            },
            colors:['#5E4AEF','#E99265','#00B1E7'],
			series:[{
				name:"15min平均",
				data:series[0]
			},{
				name:"5min平均",
				data:series[1]
			},{
				name:"1min平均",
				data:series[2]
			}],
			xAxis: {
                labels: {  
                    formatter: function() {  
                        var vDate=moment(this.value);
                        return (dateRangePicker.CPULoad.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                    }
                },
                title: {
                    text: null
                }
        	},
        	yAxis:{
        		title: {
	                text: ''
	            }
        	},
	        legend: {
	            enabled: false
	        },
	        credits: {
			    enabled: false
			},
			tooltip: {
                formatter:function(){
                    return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+'：<b>' +Highcharts.numberFormat(this.y,2,'.') +'</b>';
                }
            },
			plotOptions: {
                line: {
                    lineWidth: 1,
                    marker: {
                        enabled: false
                    },
                    shadow: false,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    }
                }
            }
		});
		$('#CPULoad').parent().find('.titlelabel').each(function(i,element){
			var colors=['#5E4AEF','#E99265','#00B1E7'];

			$(this).find('.glyphicon').css('color',colors[i]);
		});
	}
}
// CPU利用率top5
var CPUTop5 = {
	// 获取数据
	getData : function(){
		// 设置参数
		var param0 = new Object();
			
		param0.hostids = HOSTID;
		param0.application = "CPU状态";

		//通过Zabbix服务发送请求
		ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
		    
			// 对比key_值,获得itemid
			var iTemData = data.result;
			var Items = new Object();

			for (var i = 0; i < iTemData.length; i++) {

				// TOP5
				if(iTemData[i].key_ == "baseinfo[cpu_top5]"){
					Items.cputop5 = iTemData[i].itemid;
				}
			}

			var param1 = new Object();

			param1.itemids = [Items.cputop5];
			param1.limit = '';

			var cputop5Data = new Array();

			// 获取history历史数据
			ZabbixServer.sendAjaxRequest("item.get", param1, function (data) {
			   
			   var historyData = data.result;

			   for (var i = 0; i < historyData.length; i++) {
			   		
			   		// 对比itemid 将数据push到对应的数组
			   		if(historyData[i].itemid == Items.cputop5){
			   			cputop5Data.push(historyData[i].lastclock,historyData[i].lastvalue);
			   		}
			   }

			   var series = cputop5Data;

			   CPUTop5.render(series);

			});
			
		}, function(data){
		    
		    //token不存在，返回登录
		    goToLogin();

		});
	},
	// 画图
	render:function(series){
		var processes = new Array();
		var values = new Array();
		var temp = new Array();

		processes = series[1].split("|");

		for (var i = 0; i < processes.length; i++) {
			var process = new Object();

			process.value = processes[i].split(' ')[0];
			process.name = processes[i].split(' ')[1];

			temp.push(process);
		}

		$('.process').each(function(index,element){
			$(this).html(temp[index].name);
			$(this).next('.process-value').html(temp[index].value+'%');
		});
	}
}

// ;(function(){
// 	// 获取CPU利用率数据并绘图
// 	CPUPused.getData();
// 	// 获取负载数据并绘图
// 	CPULoad.getData();
// 	// 获取CPU_TOP5利用率并绘图
// 	CPUTop5.getData();

// 	setInterval(function(){
// 		// 获取CPU利用率数据并绘图
// 		CPUPused.getData();
// 		// 获取负载数据并绘图
// 		CPULoad.getData();
// 		// 获取CPU_TOP5利用率并绘图
// 		CPUTop5.getData();
// 	},15000);
// })();

;(function(){
	// 获取CPU利用率数据并绘图
    dateRangePicker.CPUPused = CPUPused;
    dateRangePicker.CPULoad = CPULoad;
    dateRangePicker.CPUTop5 = CPUTop5;
	dateRangePicker.CPUPused.getData();
	// 获取负载数据并绘图
	dateRangePicker.CPULoad.getData();
	// 获取CPU_TOP5利用率并绘图
	dateRangePicker.CPUTop5.getData();

	// setInterval(function(){
	// 	// 获取CPU利用率数据并绘图
	// 	CPUPused.getData();
	// 	// 获取负载数据并绘图
	// 	CPULoad.getData();
	// 	// 获取CPU_TOP5利用率并绘图
	// 	CPUTop5.getData();
	// },15000);
})();