// 工具文件
/**
 * 将小数精确到到指定位数
 * @param  {[string]} num [要处理的数]
 * @param  {[num]} fixed [精确到小数点后几位]
 * @return {[type]}     [返回处理后的值]
 */
function toFixed(num, fixed) {
	num = num+'';

	var index = num.indexOf(".");
	if(index == -1){
		index = num.length;
	}

	var number = num.substr(0,index+fixed+1);
	if(fixed == 0){
		number = num.substr(0,index+fixed);
	}
	return number;
}

var GlobalUtil = {
	getMax:function(numbers){
		return toFixed(Math.max.apply(Math, numbers),2);
	},
	getMin:function(numbers){
		return toFixed(Math.min.apply(Math, numbers),2);
	},
	getAverage:function(numbers){
		var sum = 0;
		for (var i = 0; i < numbers.length; i++) {
			sum += numbers[i];
		}

		return toFixed(sum/numbers.length,2);
	},
	getSize:function(number){
		var i = 0;
		var unit ='B';
		while(number>999){
			number = number/1000;
			i++;
		}
		if(i == 1){
			unit = 'KB';
		}

		if(i == 2){
			unit = "MB";
		}

		if(i == 3){
			unit = "GB";
		}
		return toFixed(number,1)+unit;
	},
	getLineNumber:function (number) {
		if(number<10){
			return '00'+number;
		}

		if(number>9&&number<100){
			return '0'+number
		}

		if(number>99){
			return number;
		}
	}
}