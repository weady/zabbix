// 获取hostid
var HOSTID = window.location.search.split('&')[0].split('=')[1];
var HOSTNAME = window.location.search.split('&')[1].split('=')[1];
var SERVICENAME = window.location.search.split('&')[2].split('=')[1];
// 初始化导航条

$('.hostname').html(HOSTNAME);
$('.servicename').html(SERVICENAME);

var detailComm = function(type) {
    return {
        type: type,
        getData: function() {
            var _this = this;
            dateRangePicker.init(_this.type);

            var type = _this.type;
            var param = new Object();

            param.hostids = HOSTID;
            param.search = {
                'key_': type == "api" ? 'homedapi.status['+SERVICENAME+']' : 'homed.resource['+SERVICENAME+',' + type + ']'
            };

            ZabbixServer.sendAjaxRequest('item.get', param, function(data){
                var param0 = new Object();

                param0[_this.methodType] = 0;
                param0.itemids = data.result[0].itemid;
                param0.time_from = _this.fromUnix || moment().add(-15,'minutes').format('X');
                param0.time_till = _this.toUnix || moment().format('X');

                ZabbixServer.sendAjaxRequest(_this.methodType + '.get', param0, function(data){
                    
                    var series =  Util.dealData(data);

                    type == "api" && series.length != 0 && $('#' + type + '').parent().parent().show();
                    Detail.render('#' + type + '', series);
                });
            });
        }
    }
}

var Detail = {
    render:function(selector,series){
        Highcharts.setOptions({
            global: {
                useUTC: false
            }
        });
        
        if(selector == '#cpu'){

            $(selector).highcharts({
                credits: {
                    text: '',
                    href: '',
                    enabled: false 
                },
                chart: {
                    zoomType: 'x',
                    type:'line',
                    backgroundColor:"#EDF2F8"
                },
                colors:["#00B8EA",'#F27D41'],
                title: {
                    text: ''
                },
                xAxis: {
                    labels: {  
                        formatter: function() {  
                            var vDate=moment(this.value);
                            return (dateRangePicker.cpu.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                        }
                    },
                    title: {
                        text: null
                    }
                },
                yAxis: {
                    title: {
                        text: ''
                    },
                    labels: {
                        formatter:function(){
                            return this.value +'%';
                        }
                    }
                },
                tooltip: {
                    formatter:function(){
                        return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+':<b>' + this.y+'%</b>';
                    }
                },
                legend: {
                    enabled: false
                },
                plotOptions: {
                    line: {
                        lineWidth: 1,
                        marker: {
                            enabled: false
                        },
                        shadow: false,
                        states: {
                            hover: {
                                lineWidth: 1
                            }
                        },
                    }
                },

                series: [{
                    type: 'line',
                    name: 'cpu利用率',
                    data: series
                }]
            });
        }
        if(selector == '#pmem'){

            $(selector).highcharts({
                credits: {
                    text: '',
                    href: '',
                    enabled: false 
                },
                chart: {
                    zoomType: 'x',
                    type:'line',
                    backgroundColor:"#EDF2F8"
                },
                colors:["#00B8EA",'#F27D41'],
                title: {
                    text: ''
                },
                xAxis: {
                    labels: {  
                        formatter: function() {  
                            var vDate=moment(this.value);
                            return (dateRangePicker.pmem.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                        }
                    },
                    title: {
                        text: null
                    }
                },
                yAxis: {
                    title: {
                        text: ''
                    },
                    labels: {
                        formatter:function(){
                            return this.value +'%';
                        }
                    }
                },
                tooltip: {
                    formatter:function(){
                        return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+':<b>' + this.y+'%</b>';
                    }
                },
                legend: {
                    enabled: false
                },
                plotOptions: {
                    line: {
                        lineWidth: 1,
                        marker: {
                            enabled: false
                        },
                        shadow: false,
                        states: {
                            hover: {
                                lineWidth: 1
                            }
                        },
                    }
                },

                series: [{
                    type: 'line',
                    name: 'cpu利用率',
                    data: series
                }]
            });
        }
        if(selector == '#mem'){

            $(selector).highcharts({
                credits: {
                    text: '',
                    href: '',
                    enabled: false 
                },
                chart: {
                    zoomType: 'x',
                    type:'line',
                    backgroundColor:"#EDF2F8"
                },
                colors:["#00B8EA",'#F27D41'],
                title: {
                    text: ''
                },
                xAxis: {
                    labels: {  
                        formatter: function() {  
                            var vDate=moment(this.value);
                            return (dateRangePicker.mem.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                        }
                    },
                    title: {
                        text: null
                    }
                },
                yAxis: {
                    title: {
                        text: ''
                    },
                    labels: {
                        formatter:function(){
                            return GlobalUtil.getSize(this.value);
                        }
                    }
                },
                tooltip: {
                    formatter:function(){
                        return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+':<b>' + GlobalUtil.getSize(this.y)+'</b>';
                    }
                },
                legend: {
                    enabled: false
                },
                plotOptions: {
                    line: {
                        lineWidth: 1,
                        marker: {
                            enabled: false
                        },
                        shadow: false,
                        states: {
                            hover: {
                                lineWidth: 1
                            }
                        },
                    }
                },

                series: [{
                    type: 'line',
                    name: '内存占用量',
                    data: series
                }]
            });
        }
        if(selector == '#api'){

            $(selector).highcharts({
                credits: {
                    text: '',
                    href: '',
                    enabled: false 
                },
                chart: {
                    zoomType: 'x',
                    type:'line',
                    backgroundColor:"#EDF2F8"
                },
                colors:["#00B8EA",'#F27D41'],
                title: {
                    text: ''
                },
                xAxis: {
                    labels: {  
                        formatter: function() {  
                            var vDate=moment(this.value);
                            return (dateRangePicker.api.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                        }
                    },
                    title: {
                        text: null
                    }
                },
                yAxis: {
                    title: {
                        text: ''
                    },
                    labels: {
                        formatter:function(){
                            return this.value;
                        }
                    }
                },
                tooltip: {
                    formatter:function(){
                        return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+':<b>' + this.y+'ms</b>';
                    }
                },
                legend: {
                    enabled: false
                },
                plotOptions: {
                    line: {
                        lineWidth: 1,
                        marker: {
                            enabled: false
                        },
                        shadow: false,
                        states: {
                            hover: {
                                lineWidth: 1
                            }
                        },
                    }
                },

                series: [{
                    type: 'line',
                    name: 'api耗时',
                    data: series
                }]
            });
        }
    }
}
var Util = {
    // 处理数据
    dealData:function(data){
        
        var datalist = new Array(),
            tempData = data.result;

        for (var i = 0; i < tempData.length; i++) {
            
            datalist.push([parseInt(tempData[i].clock) * 1000, parseFloat(tempData[i].value || tempData[i].value_avg)]);

        }

        return datalist;
    }
}

;(function ($,window) {
    dateRangePicker.cpu = detailComm("cpu");
    dateRangePicker.pmem = detailComm("pmem");
    dateRangePicker.mem = detailComm("mem");
    dateRangePicker.api = detailComm("api");

    dateRangePicker.cpu.getData();
    dateRangePicker.pmem.getData();
    dateRangePicker.mem.getData();
    dateRangePicker.api.getData();

    // Detail.getCPU()
    // Detail.getPmem()
    // Detail.getMem()
    // Detail.getApi()
})(jQuery,window);