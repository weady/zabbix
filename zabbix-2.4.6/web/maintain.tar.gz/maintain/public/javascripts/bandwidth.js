// 带宽监测主机对象
var Host = {
	/**
	 * 获取主机列表
	 */
	getData: function () {
		
		var param = {
			'search':{
				'key_':'zabbix.data[get_ilogslave_hosts]'
			}
		}

		ZabbixServer.sendAjaxRequest('item.get',param,function(data){
			
			var result = data.result;
			
			// 拆分字段后的数组，用于缓存获取到的slave主机名
			var hostArray = new Array();

			for (var i = 0; i < result.length; i++) {
				
				if(result[i].templateid !== '0'){
					
					var hostStringArr = result[i].lastvalue.split('\n');
					for (var j = 0; j < hostStringArr.length; j++) {
						hostArray.push({
							id:hostStringArr[j].split('|')[0],
							name:hostStringArr[j].split('|')[1]
						});

					}

				}

			}
			// 将主机列表添加到页面
			Host.addDom(hostArray);
			// 绑定事件
			Host.bindEvent();

			// 获取推流总带宽
			StreamBandWidth.getData('','total');

		});

	},
	/**
	 * 添加主机节点
	 * @param {[type]} hostArray [description]
	 */
	addDom : function(hostArray){
		
		var dom = '<div class="col-md-1 col-sm-2 col-xs-3 text-center"><span class="item active" data-hostid="">总带宽</span></div>';

		for (var i = 0; i < hostArray.length; i++) {
			dom += '<div class="col-md-1 col-sm-2 col-xs-3 text-center"><span class="item" data-hostid="'+hostArray[i].id+'">'+hostArray[i].name+'</span></div>';
		}

		$('.hostlist').children().remove();
		$('.hostlist').append(dom);
	},
	bindEvent: function(){
		$(document).off('click','#stream .item');
		$(document).on('click','#stream .item',function(){
			
			var $this = $(this);

			var hostid = $this.data('hostid');

			StreamBandWidth.getData(hostid);

			$this.parent().parent().find('.item').removeClass('active');
			$this.addClass('active');
		});

        $(document).off('click','#ConcurrentList .item');
        $(document).on('click','#ConcurrentList .item',function(){
            
            var $this = $(this);

            var type = $('#type').val();
            var hostid = $this.data('hostid');
            Concurrent.getData(type,hostid);

            $this.parent().parent().find('.item').removeClass('active');
            $this.addClass('active');
        });
	}
}

// 推流带宽
var StreamBandWidth = {
	getData: function(hostid){
        var _this = this;
        dateRangePicker.argsCache("StreamBandWidth", { hostid: hostid });
        hostid = _this.argsCache.hostid;

        dateRangePicker.init("StreamBandWidth");

		// 获取推流总带宽
		var param0 ;
		if(hostid == ''){

			param0 = {
				'search':{
					'key_':'zabbix.data[get_push_bandwith]'
				}
			}

		// 获取单台主机上的带宽
		}else{
			param0 = {
				'hostids':hostid,
				'search':{
					'key_':'baseinfo[ilogslave_rate]'
				}
			}
		}

		ZabbixServer.sendAjaxRequest('item.get',param0,function(data){

			var result = data.result;
			var itemid;
			for (var i = 0; i < result.length; i++) {
				
				if(result[i].templateid !== '0'){

					itemid = result[i].itemid;

				}
			}

			var param1 = {
				itemids:itemid,
				time_from: _this.fromUnix || moment().add(-15,'minutes').format('X'),
				time_till: _this.toUnix || moment().format('X')
			}
            param1[_this.methodType] = 3;
			ZabbixServer.sendAjaxRequest(_this.methodType + '.get',param1,function(data){
				var series = new Array();

				var result = data.result;

				for (var i = 0; i < result.length; i++) {
					series.push([parseInt(result[i].clock) * 1000, parseInt(result[i].value || result[i].value_avg)]);
				}

				StreamBandWidth.render(series)
			});
		});
		

	},
	render:function(series){
		Highcharts.setOptions({
		    global: {
		        useUTC: false
		    }
		});

		$('#StreamBandWidth').highcharts({
		    credits: {
		        text: '',
		        href: '',
		        enabled: false 
		    },
		    chart: {
		        zoomType: 'x',
		        backgroundColor:"#EDF2F8"
		    },
		    colors:["#E87F69","#9020CB"],
		    title: {
		        text: ''
		    },
		    xAxis: {
                labels: {  
                    formatter: function() {  
                        var vDate=moment(this.value);
                        return (dateRangePicker.StreamBandWidth.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                    }
                },
                title: {
                    text: null
                }
		    },
		    yAxis: {
		        title:{
		            text:''
		        }
		    },
		    tooltip: {
		        formatter:function(){
		            return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+'：<b>' +GlobalUtil.getSize(this.y) +'</b>';
		        }
		    },
		    legend: {
		        enabled: false
		    },
		    plotOptions: {
		        line: {
		            lineWidth: 1,
		            marker: {
		                enabled: false
		            },
		            shadow: false,
		            states: {
		                hover: {
		                    lineWidth: 1
		                }
		            }
		        }
		    },

		    series: [{
		        type:'line',
		        name:'带宽',
		        data: series
		    }]
		}); 
	}
}

// 并发对象
var Concurrent = {
    // 根据设备类型获取数据
    getData: function(type, hostid){
        dateRangePicker.argsCache("Concurrent", { type: type, hostid: hostid });
        type = this.argsCache.type;
        hostid = this.argsCache.hostid;

        dateRangePicker.init("Concurrent");
        // console.log("getData:")
        // console.log("type: "+type +"; hostid: "+hostid);
        // 获取total
        switch(type){
            case 'total':Concurrent.getDetail('total',hostid);break;
            case 'stb':Concurrent.getDetail('stb',hostid);break;
            case 'smartcard':Concurrent.getDetail('smartcart',hostid);break;
            case 'mobile':Concurrent.getDetail('mobile',hostid);break;
            case 'pad':Concurrent.getDetail('pad',hostid);break;
            case 'pc':Concurrent.getDetail('pc',hostid);break;
        }
    },
    getDetail:function(type,hostid){
        var _this = this;

        var param0 = new Object();
        var reg;

        if(hostid){
            param0.application = '单机并发数';
            param0.hostids = hostid;

            if(type == 'total'){
                reg = 'total]';
            }

            if(type == 'stb'){
                reg = "stb]"
            }
            if(type == 'mobile'){
                reg = "mobile]"
            }
            if(type == 'smartcard'){
                reg = "smartcard]"
            }
            if(type == 'pad'){
                reg = "pad]"
            }
            if(type == 'pc'){
                reg = "pc]"
            }
        }else{
            param0.application = "集群并发数";

            if(type == 'total'){
                reg = '\\[total';
            }

            if(type == 'stb'){
                reg = "\\[stb"
            }
            if(type == 'mobile'){
                reg = "\\[mobile"
            }
            if(type == 'smartcard'){
                reg = "\\[smartcard"
            }
            if(type == 'pad'){
                reg = "\\[pad"
            }
            if(type == 'pc'){
                reg = "\\[pc"
            }
        }

        ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
            //通过主机列表获取主机的各项数据
            var datas = data.result;
            var totalObject = new Object();
            
            var totalreg = new RegExp(reg);

            // 如果有主机id,则为获取单击上的并发数
            if(hostid){
                for (var i = 0; i < datas.length; i++) {
                    if(totalreg.test(datas[i].key_)){
                        // 时移
                        if(datas[i].key_.split(',')[1]=='ts_total'){
                            totalObject.tstotalItem = datas[i].itemid;
                        }
                        
                        // 电影
                        if(datas[i].key_.split(',')[1]=='movie'){
                            totalObject.movieItem = datas[i].itemid;
                        }
                        // 回看
                        if(datas[i].key_.split(',')[1]=='tr'){
                            totalObject.trItem = datas[i].itemid;
                        }
                        
                        // 直播
                        if(datas[i].key_.split(',')[1]=='live'){
                            totalObject.liveItem = datas[i].itemid;
                        }
                        // 总量
                        if(datas[i].key_.split(',')[1]=='total'){
                            totalObject.totalItem = datas[i].itemid;
                        }
                    }
                }
            }else{
                for (var i = 0; i < datas.length; i++) {
                    if(totalreg.test(datas[i].key_)){
                        // 电影
                        if(datas[i].key_.split(',')[1].split(']')[0]=='movie'){
                            totalObject.movieItem = datas[i].itemid;
                        }
                        // 回看
                        if(datas[i].key_.split(',')[1].split(']')[0]=='tr'){
                            totalObject.trItem = datas[i].itemid;
                        }
                      
                        // 直播
                        if(datas[i].key_.split(',')[1].split(']')[0]=='live'){
                            totalObject.liveItem = datas[i].itemid;
                        }
                        // 总量
                        if(datas[i].key_.split(',')[1].split(']')[0]=='total'){
                            totalObject.totalItem = datas[i].itemid;
                        }
                        // 时移
                        if(datas[i].key_.split(',')[1].split(']')[0]=='ts_total'){
                            totalObject.tstotalItem = datas[i].itemid;
                        }
                    }
                } 
            }
            

            var itemids = new Array();
            $.each(totalObject,function(key,value){
                itemids.push(value);
            });

            // console.log(itemids)
            var param1 = new Object();
            param1.itemids = itemids;
            param1.time_from = _this.fromUnix || moment().startOf('day').format('X');
            param1.time_till = _this.toUnix || moment().format('X');
            param1.limit = "";

           
            var movieArray = new Array(),
                trArray = new Array(),
                liveArray = new Array(),
                totalArray = new Array(),
                tstotalArray = new Array();

            ZabbixServer.sendAjaxRequest(_this.methodType + ".get", param1, function (data) {
                
                var historyData = data.result;

                for (var i = 0; i < historyData.length; i++) {
                        
                        // 电影
                        if(historyData[i].itemid == totalObject.movieItem){
                            movieArray.push([parseFloat(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
                        }
                        // 回看
                        if(historyData[i].itemid == totalObject.trItem){
                            trArray.push([parseFloat(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
                        }
                       
                        // 直播
                        if(historyData[i].itemid == totalObject.liveItem){
                            liveArray.push([parseFloat(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
                        }
                        // 总量
                        if(historyData[i].itemid == totalObject.totalItem){
                            totalArray.push([parseFloat(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
                        }
                        // 时移
                        if(historyData[i].itemid == totalObject.tstotalItem){
                            tstotalArray.push([parseFloat(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
                        }

                }

                var series = [totalArray,trArray,movieArray,liveArray,tstotalArray];

                Highcharts.setOptions({ global: { useUTC: false } });
                $('#Concurrent').highcharts({
                    title:{
                        text:""
                    },
                    chart:{
                        zoomType: 'x',
                        type:'line',
                        backgroundColor:"#EDF2F8"
                    },
                    colors:['#00B101','#00A7EB','#FF5F5C','#FFD300','#FE17B5','#FE17B5'],
                    series:[{
                        name:"总量",
                        data:series[0]
                    },{
                        name:"回看",
                        data:series[1]
                    },{
                        name:"电影",
                        data:series[2]
                    },{
                        name:"直播",
                        data:series[3]
                    },{
                        name:"时移",
                        data:series[4]
                    }],
                    xAxis: {
                        labels: {  
                            formatter: function() {  
                                var vDate=moment(this.value);
                                return (dateRangePicker.Concurrent.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                            }
                        },
                        title: {
                            text: null
                        }
                    },
                    yAxis:{
                        tickInterval:10,
                        title: {
                            text: ''
                        },
                        labels: {
                            format: '{value} '
                        }
                    },
                    legend: {
                        enabled: false
                    },
                    tooltip: {
                        formatter:function(){
                            return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+'：<b>' +Highcharts.numberFormat(this.y,2,'.') +'</b>';
                        }
                    },
                    credits: {
                        enabled: false
                    },
                    plotOptions: {
                        line: {
                            lineWidth: 2,
                            marker: {
                                enabled: false
                            },
                            shadow: false,
                            showPoint:true,
                            states: {
                                hover: {
                                    lineWidth: 2
                                }
                            }
                        }
                    }
                });
            });
            
            var colors=['#00B101','#00A7EB','#FF5F5C','#FFD300','#FE17B5'];

            $('.datalabel').find('.glyphicon').each(function(index,element){
                $(this).css('color',colors[index])
            });

        }, function(data){
            //token不存在，返回登录
            goToLogin();

        })
    },
    bindEvent:function(){
        // 表格的切换
        var timing = null;
        $('#chartitle, .glyphicon-chevron-down').click(function(){
            $('.chartlist').stop(1).slideToggle();
            timing = (function() {
                clearTimeout(timing);
                timing = null;
                return setTimeout(function() {
                    $('.chartlist').slideUp();
                }, 1500);
            })();
        });

        $('.chartlist').mouseover(function(){
            $('.chartlist').show();
            clearTimeout(timing);
            timing = null;
        });
        $('.chartlist').mouseleave(function(){
            $('.chartlist').slideUp();
        });
        $('.chartlist li').click(function(){
            var action = $(this).data('action'),
                html = $(this).html();

            $('#chartitle').html(html);
            $('#type').val(action);
            $('.chartlist').hide();

            var reg = $(this).data('action');
            var hostid = $('#ConcurrentList').find('.active').eq(0).data('hostid');
            dateRangePicker.Concurrent.getDetail(reg,hostid);
        })
    }
}


;(function(){
	// 获取主机列表
	// Host.getdata();
	// Concurrent.getData('total');
 //    Concurrent.bindEvent();

 //    setInterval(function(){
 //        var type = $('#type').val();
 //        var hostid = $('#concurrent').find('.active').eq(0).data('hostid');

 //        console.log(type);
 //        console.log(hostid);
 //        Concurrent.getData(type,hostid);
 //    },30000);
    dateRangePicker.Host = Host;
    dateRangePicker.StreamBandWidth = StreamBandWidth;
    dateRangePicker.Concurrent = Concurrent;

    dateRangePicker.Host.getData();
    dateRangePicker.Concurrent.getData("total");
    dateRangePicker.Concurrent.bindEvent();
})();