var options = new Object();
options.url = "http://192.168.35.114//zabbix/api_jsonrpc.php";

var ZabbixServer 	= new $.jqzabbix(options);

// $(document).ajaxStart(function() {
//     console.info('First ajax request start!')
// });
// $(document).ajaxStop(function() {
//     console.info('All ajax request finished!');
// });

function doLogin(form){
    options.username = form.username.value;
    options.password = form.password.value;
    ZabbixServer.getApiVersion(null);
    ZabbixServer.setOptions(options);
    ZabbixServer.userLogin(null, function(data){
       
    	$.cookie("token",data.result);
        $.cookie("id",data.id);
    	$.cookie("username",options.username);
        window.location.href = "index.html"
    },
    function(data) {
        $('.alert').addClass('show');
        setTimeout(function() {
            $('.alert').removeClass('show');
        }, 1500);
    });
}

function logout(){
    ZabbixServer.userLogout(null, function(data){
        
        top.window.location.href="../login.html"
   
    },null);
}


function goToLogin(){
    top.window.location.href="../login.html"
}

(function() {
    $('.username').text($.cookie('username'));
    $('.avatar').find('ul').addClass('dropdown-menu').css({
        'top': '27px',
        'left': '-15px',
        'width': '60px',
        'min-width': '60px',
        'text-align': 'center',
        'padding-right': '10px'
    });
})();