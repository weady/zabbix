//主机
var Host = {
    Field: {
        $hostCount: $('#hostCount')
    },
    //获取数量
    getCount: function() {
        //通过Zabbix服务发送请求
        ZabbixServer.sendAjaxRequest("host.get", null, function(data) {
            //修改host主机数
                    
            var arr = new Array();
            var onlineCount = 0,
                offlineCount = 0;

            for (var i = 0; i < data.result.length; i++) {
                if(data.result[i].snmp_available === '0'){
                    arr.push(data.result[i].hostid);
                }

                if(data.result[i].available == '2'){
                    offlineCount ++;
                }
                if(data.result[i].available == '1'){
                    onlineCount++;
                }

            }

            var totalDom = '<a class="label label-info" href="hostlist.html?flag=3">'+arr.length+'</a>'
            Host.Field.$hostCount.html(totalDom);

            
            var onlineDom = '<a class="label label-success" href="hostlist.html?flag=0">'+onlineCount+'</a>',
                offlineDom = '<a class="label label-danger" href="hostlist.html?flag=1">'+offlineCount+'</a>';

            if(onlineCount==0){
                onlineDom = '<span class="label label-success">0</span>'
            }

            if(offlineCount==0){
                offlineDom = '<span class="label label-danger">0</span>'
            }

            $('#onlineCount').append(onlineDom);
            $('#offlineCount').append(offlineDom);
            
        }, function(data) {
            //token不存在，返回登录
            goToLogin();

        });
    }
}

//频道录流
var ChnlStream = {
    Field: {
        $chnlStreamCount: $('#chnlStreamCount'),
        $normalStreamCount: $('#normalStreamCount'),
        $abnormalStreamCount: $('#abnormalStreamCount')
    },
    getCount: function() {
        //获取频道录流总数
        //获取hostid
        var params = new Object();
        params.application = "频道录流监控";

        ZabbixServer.sendAjaxRequest("item.get", params, function(data) {
            var totalcount = 0,
                normalcount = 0,
                abnormalcount = 0;

            for (var i = 0; i < data.result.length; i++) {

                if(data.result[i].state != 1){
                    totalcount++;

                    if (data.result[i].lastvalue == '0') {
                        abnormalcount++;
                    }else{
                        normalcount++;
                    }
                }
            }

            var abnormalDom = '<a class="label label-danger" href="streammonitor.html?flag=0">'+abnormalcount+'</a>',
                normalDom = '<a class="label label-success" href="streammonitor.html?flag=1">'+normalcount+'</a>',
                totalDom = '<a class="label label-info" href="streammonitor.html?flag=3">'+totalcount+'</a>';

            if(abnormalcount==0){
                abnormalDom = '<span class="label label-danger">0</span>'
            }

            if(normalcount==0){
                normalDom = '<span class="label label-success">0</span>'
            }


            ChnlStream.Field.$chnlStreamCount.append(totalDom);
            //正常录流
            ChnlStream.Field.$normalStreamCount.append(normalDom);
            //异常录流
            ChnlStream.Field.$abnormalStreamCount.append(abnormalDom);

        }, function(data) {
            //token不存在，返回登录
            goToLogin();

        })
    },
    render: function(normalcount, abnormalcount) {
        var $StreamStatusPie = $("#streamStatus")

        var data = [{
            "label": "正常录流",
            "data": normalcount
        }, {
            "label": "异常录流",
            "data": abnormalcount
        }];

        var piePolt = $.plot($StreamStatusPie, data, {
            series: {
                pie: {
                    radius: 500,
                    show: true,
                    label: {
                        show: false
                    }
                }
            },
            colors: ["#00A6E4", "#16CDD5", "#5CD8F2"],
            legend: {
                show: false // 屏蔽原来的legend
            }
        });
    }
}

// 实时在线用户数量
var UserCount = {
    getData:function(){
        var _this = this;
        dateRangePicker.init("UserCount");
        
        var param0 = new Object();
        param0.application = "集群并发数";
        param0.search = {
            key_:'cluster.reg_online[homed_online_num]'
        }

        var useritem = '';
        ZabbixServer.sendAjaxRequest('item.get',param0,function(data){
            var data = data.result;

            for (var i = 0; i < data.length; i++) {
                if(data[i].templateid !== '0'){
                    useritem = data[i].itemid;
                }
            }

            var param1 = {
                itemids: useritem,
                time_from: _this.fromUnix || moment().startOf('day').format('X'),
                time_till: _this.toUnix || moment().format('X'),
                limit:''
            }

            ZabbixServer.sendAjaxRequest(_this.methodType+'.get',param1,function(data){
                
                var series = new Array();

                for (var i = 0, d; d = data.result[i++];) {
                    var time = parseInt(d.clock*1000),
                        value = parseInt(d.value || d.value_avg);

                    series.push([time,value]);
                }

                UserCount.render(series);
            });

        });

    },
    render:function(series){
        Highcharts.setOptions({ global: { useUTC: false } });
        $('#UserCount').highcharts({
            credits: {
                text: '',
                href: '',
                enabled: false 
            },
            chart: {
                zoomType: 'x',
                type:'area',
                backgroundColor:"#EDF2F8"
            },
            colors:["#7C2CFD"],
            title: {
                text: ''
            },
            xAxis: {
                labels: {  
                    formatter: function() {  
                        var vDate=moment(this.value);
                        return (dateRangePicker.UserCount.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                    }
                },
                title: {
                    text: null
                }
            },
            yAxis: {
                title: {
                    text: ''
                }
            },
            tooltip: {
                shared: true,
                formatter:function(){
                    return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br><b>实时在线用户数量：</b>' + this.y+'</b>';
                }
            },
            legend: {
                enabled: false
            },
            plotOptions: {
                area: {
                    fillColor: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1},
                        stops: [
                            [0, "#7C2CFD"],
                            [1, Highcharts.Color("#7C2CFD").setOpacity(0).get('rgba')]
                        ]
                    },
                    lineWidth: 1,
                    marker: {
                        enabled: false
                    },
                    shadow: false,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    },
                }
            },

            series: [{
                type: 'area',
                name: 'value',
                data: series
            }]
        }); 
    }
}

// 并发对象
var Concurrent = {
    // 根据设备类型获取数据
    getData:function(){
        type = this.type || "total";
        this.type = type;
        dateRangePicker.init("Concurrent");
        // 获取total
        switch(type){
            case 'total':Concurrent.getDetail('\\[total');break;
            case 'stb':Concurrent.getDetail('\\[stb');break;
            case 'smartcard':Concurrent.getDetail('\\[smartcart');break;
            case 'mobile':Concurrent.getDetail('\\[mobile');break;
            case 'pad':Concurrent.getDetail('\\[pad');break;
            case 'pc':Concurrent.getDetail('\\[pc');break;
        }
    },
    getDetail:function(reg){
        var _this = this;
        var param0 = new Object();
        param0.application = "集群并发数";

        ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
            //通过主机列表获取主机的各项数据
            var datas = data.result;
            var totalObject = new Object();
            var totalreg = new RegExp(reg);
            for (var i = 0, d; d = datas[i++];) {
                if(totalreg.test(d.key_)){
                    var type = d.key_.split(',')[1].split(']')[0];
                    // 电影
                    if(type == 'movie'){
                        totalObject.movieItem = d.itemid;
                    }
                    // 回看
                    if(type == 'tr'){
                        totalObject.trItem = d.itemid;
                    }
                  
                    // 直播
                    if(type == 'live'){
                        totalObject.liveItem = d.itemid;
                    }
                    // 总量
                    if(type == 'total'){
                        totalObject.totalItem = d.itemid;
                    }
                    // 时移
                    if(type == 'ts_total'){
                        totalObject.tstotalItem = d.itemid;
                    }
                }
            }

            var itemids = new Array();
            $.each(totalObject,function(key,value){
                itemids.push(value);
            });
            var param1 = new Object();
            param1.itemids = itemids;
            param1.time_from = _this.fromUnix || moment().startOf('day').format('X');
            param1.time_till = _this.toUnix || moment().format('X');
            param1.limit=""

           
            var movieArray = new Array(),
                trArray = new Array(),
                liveArray = new Array(),
                totalArray = new Array(),
                tstotalArray = new Array();

            ZabbixServer.sendAjaxRequest(_this.methodType + ".get", param1, function (data) {
                
                var historyData = data.result;

                for (var i = 0; i < historyData.length; i++) {
                        
                        // 电影
                        if(historyData[i].itemid == totalObject.movieItem){
                            movieArray.push([parseFloat(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
                        }
                        // 回看
                        if(historyData[i].itemid == totalObject.trItem){
                            trArray.push([parseFloat(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
                        }
                       
                        // 直播
                        if(historyData[i].itemid == totalObject.liveItem){
                            liveArray.push([parseFloat(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
                        }
                        // 总量
                        if(historyData[i].itemid == totalObject.totalItem){
                            totalArray.push([parseFloat(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
                        }
                        // 时移
                        if(historyData[i].itemid == totalObject.tstotalItem){
                            tstotalArray.push([parseFloat(historyData[i].clock)*1000,parseFloat(historyData[i].value || historyData[i].value_avg)]);
                        }

                }

                var series = [totalArray,trArray,movieArray,liveArray,tstotalArray];

                Highcharts.setOptions({ global: { useUTC: false } });
                $('#Concurrent').highcharts({
                    title:{
                        text:""
                    },
                    chart:{
                        zoomType: 'x',
                        type:'line',
                        backgroundColor:"#EDF2F8"
                    },
                    colors:['#00B101','#00A7EB','#FF5F5C','#FFD300','#FE17B5','#FE17B5'],
                    series:[{
                        name:"总量",
                        data:series[0]
                    },{
                        name:"回看",
                        data:series[1]
                    },{
                        name:"电影",
                        data:series[2]
                    },{
                        name:"直播",
                        data:series[3]
                    },{
                        name:"时移",
                        data:series[4]
                    }],
                    xAxis: {
                        labels: {  
                            formatter: function() {  
                                var vDate=moment(this.value);
                                return (dateRangePicker.Concurrent.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                            }
                        },
                        title: {
                            text: null
                        }
                    },
                    yAxis:{
                        tickInterval:10,
                        title: {
                            text: ''
                        },
                        labels: {
                            format: '{value} '
                        }
                    },
                    legend: {
                        enabled: false
                    },
                    tooltip: {
                        formatter:function(){
                            return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+'：<b>' +Highcharts.numberFormat(this.y,2,'.') +'</b>';
                        }
                    },
                    credits: {
                        enabled: false
                    },
                    plotOptions: {
                        line: {
                            lineWidth: 2,
                            marker: {
                                enabled: false
                            },
                            shadow: false,
                            showPoint:true,
                            states: {
                                hover: {
                                    lineWidth: 2
                                }
                            }
                        }
                    }
                });
            });
            
            var colors=['#00B101','#00A7EB','#FF5F5C','#FFD300','#FE17B5'];

            $('.datalabel').find('.glyphicon').each(function(index,element){
                $(this).css('color',colors[index])
            });

        }, function(data){
            //token不存在，返回登录
            goToLogin();

        })
    },
    bindEvent:function(){
        // 表格的切换
        var _this  = this;
        var timing = null;
        $('#chartitle, .glyphicon-chevron-down').click(function(){
            $('.chartlist').stop(1).slideToggle();
            timing = (function() {
                clearTimeout(timing);
                timing = null;
                return setTimeout(function() {
                    $('.chartlist').slideUp();
                }, 1500);
            })();
        });

        $('.chartlist').mouseover(function(){
            $('.chartlist').show();
            clearTimeout(timing);
            timing = null;
        });
        $('.chartlist').mouseleave(function(){
            $('.chartlist').slideUp();
        });
        $('.chartlist li').click(function(){
            $('#chartitle').html($(this).html());
            $('#chartitle').attr('data-action',$(this).data('action'));
            $('.chartlist').hide();
            var reg = '\\['+$(this).data('action');
            // _this.methodType = "history";
            _this.type = $(this).data('action');
            // console.log(reg);
            dateRangePicker.Concurrent.getDetail(reg);
        })
    }
}

// HDFS磁盘利用率
var HDFSUseage = {
    // 获取数据
    getData: function() {
        var _this = this;
        dateRangePicker.init("HDFSUseage");

        // 获取主机
        // 获取
        var param0 = new Object();

        param0.application = "HDFS Status";
        param0.search = {
            'key_':'hdfs.resource[dfs.pused]'
        };

        ZabbixServer.sendAjaxRequest("item.get", param0, function(data1) {
            var itemid = data1.result[0].itemid;
            
            var utcstart = _this.fromUnix || moment().add(-30, "day").format("X");
            var utcend = _this.toUnix || moment().format("X");


            var params = new Object();
            params.itemids = itemid;
            params[_this.methodType] = 0;
            params.time_from = utcstart;
            params.time_till = utcend;
            params.limit = '';

            ZabbixServer.sendAjaxRequest(_this.methodType + ".get", params, function(data) {
                var d = [];
                var min = 100;
                var max = 0;
                var datas = new Array();
                var dataValues = new Array();

                for (var i = 0; i < data.result.length; i++) {
                    var time = parseInt(data.result[i].clock * 1000);
                    var value = data.result[i].value || data.result[i].value_avg;

                    datas.push([parseInt(time),parseFloat(value)]);
                    dataValues.push(parseFloat(value));
                    
                }

                HDFSUseage.render(datas,dataValues);

            });
        }, function(data) {
            //token不存在，返回登录
            goToLogin();

        })
    },
    // 绘制图形
    render: function(series,dataValues) {
        var max = parseInt(GlobalUtil.getMax(dataValues))+5;
        var min = parseInt(GlobalUtil.getMin(dataValues))-5;

        Highcharts.setOptions({ global: { useUTC: false } });
        
        $('#HDFSUseage').highcharts({
            credits: {
                text: '',
                href: '',
                enabled: false 
            },
            chart: {
                zoomType: 'x',
                type:'line',
                backgroundColor:"#EDF2F8"
            },
            colors:["#E98671"],
            title: {
                text: ''
            },
            xAxis: {
                labels: {  
                    formatter: function() {  
                        var vDate=moment(this.value);
                        return (dateRangePicker.HDFSUseage.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                    }
                },
                title: {
                    text: null
                }
            },
            yAxis: {
                max:max,
                min:min,
                tickInterval:1,
                title: {
                    text: ''
                },
                labels: {
                    format: '{value} %'
                }
            },
            tooltip: {
                shared: true,
                formatter:function(){
                    return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/HDFS磁盘利用率：<b>' + this.y+'%</b>';
                }
            },
            legend: {
                enabled: false
            },
            plotOptions: {
                area: {
                    fillColor: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1},
                        stops: [
                            [0, "#E98671"],
                            [1, Highcharts.Color("#E98671").setOpacity(0).get('rgba')]
                        ]
                    },
                    lineWidth: 1,
                    marker: {
                        enabled: false
                    },
                    shadow: false,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    },
                }
            },

            series: [{
                type: 'area',
                name: 'value',
                data: series
            }]
        }); 
    }
}

// HDFS状态
var HDFSStutas = {
    getData: function() {
        var param0 = new Object();
        param0.application = 'HDFS Status';

        ZabbixServer.sendAjaxRequest('item.get',param0,function(data1){
            var itemids = new Array();
            var datas =  data1.result;
            for (var i = 0; i < datas.length; i++) {
                itemids.push(datas[i].itemid)
            }

            var utcstart = moment().add(-12, "hour").format("X");
            var utcend = moment().format("X");

            var params = new Object();
            params.itemids = itemids;

            ZabbixServer.sendAjaxRequest("item.get", params, function(data) {

                var statusDataObj = new Object();

                for (var i = data.result.length - 1; i >= 0; i--) {
                    // 总空间
                    if (data.result[i].key_ == "hdfs.resource[total]") {

                        var total = new Object();
                        total.value = data.result[i].lastvalue;
                        total.units = data.result[i].units;
                        statusDataObj.total = total;

                    }
                    // 已用空间
                    if (data.result[i].key_ == "hdfs.resource[dfs.used]") {

                        var dfsused = new Object();
                        dfsused.value = data.result[i].lastvalue;
                        dfsused.units = data.result[i].units;
                        statusDataObj.dfsused = dfsused;

                    }
                    // DFS Non Used
                    if (data.result[i].key_ == "hdfs.resource[non.dfs.used]") {

                        var nondfsused = new Object();
                        nondfsused.value = data.result[i].lastvalue;
                        nondfsused.units = data.result[i].units;
                        statusDataObj.nondfsused = nondfsused;

                    }
                    // 剩余空间
                    if (data.result[i].key_ == "hdfs.resource[dfs.remaining]") {

                        var remaining = new Object();
                        remaining.value = data.result[i].lastvalue;
                        remaining.units = data.result[i].units;
                        statusDataObj.remaining = remaining;

                    }

                    if (data.result[i].key_ == "hdfs.resource[dfs.premaining]") {

                        var premaining = new Object();
                        premaining.value = data.result[i].lastvalue;
                        premaining.units = data.result[i].units;
                        statusDataObj.premaining = premaining;

                    }
                    if (data.result[i].key_ == "hdfs.resource[live.nodes]") {

                        var livenodes = new Object();
                        livenodes.value = data.result[i].lastvalue;
                        livenodes.units = data.result[i].units;
                        statusDataObj.livenodes = livenodes;

                    }
                    if (data.result[i].key_ == "hdfs.resource[dead.nodes]") {

                        var deadnodes = new Object();
                        deadnodes.value = data.result[i].lastvalue;
                        deadnodes.units = data.result[i].units;
                        statusDataObj.deadnodes = deadnodes;

                    }
                    if (data.result[i].key_ == "hdfs.resource[dead.nodes.name]") {

                        var deadnodesname = new Object();
                        deadnodesname.value = data.result[i].lastvalue;
                        deadnodesname.units = data.result[i].units;
                        statusDataObj.deadnodesname = deadnodesname;

                    }
                    if (data.result[i].key_ == "hdfs.resource[decom.nodes]") {

                        var decomnodes = new Object();
                        decomnodes.value = data.result[i].lastvalue;
                        decomnodes.units = data.result[i].units;
                        statusDataObj.decomnodes = decomnodes;

                    }
                }

                $(".hdfstotal").html(Highcharts.numberFormat(statusDataObj.total.value, 2, '.') + statusDataObj.total.units);
                $("#hdfsused").html(Highcharts.numberFormat(statusDataObj.dfsused.value, 2, '.') + statusDataObj.dfsused.units);
                $("#nondfsused").html(Highcharts.numberFormat(statusDataObj.nondfsused.value, 2, '.') + statusDataObj.nondfsused.units);
                $("#remaining").html(Highcharts.numberFormat(statusDataObj.remaining.value, 2, '.') + statusDataObj.remaining.units);
                $("#premaining").html(Highcharts.numberFormat(statusDataObj.premaining.value, 2, '.') + statusDataObj.premaining.units);
                $("#livenodes").html(statusDataObj.livenodes.value + statusDataObj.livenodes.units);
                $("#deadnodes").html(statusDataObj.deadnodes.value + statusDataObj.deadnodes.units);
                $("#decomnodes").html(statusDataObj.decomnodes.value + statusDataObj.decomnodes.units);
                $("#deadnodesname").html(statusDataObj.deadnodesname.value);

                HDFSStutas.render(statusDataObj);

            });
        }, function(data) {
            //token不存在，返回登录
            goToLogin();

        });
    },
    render: function(data) {
        var $chartObj = $("#useagePie"),
            $dfsUsedPercent = $("#dfsUsedPercent"),
            $dfsNonUsedPercent = $("#dfsNonUsedPercent"),
            $remainPercent = $("#remainPercent"),
            used = toFixed(data.dfsused.value, 2),
            nonused = toFixed(data.nondfsused.value, 2),
            remaining = toFixed(data.remaining.value, 2);
            total = toFixed(data.total.value, 2)+data.total.units;
        
        // $('#useagePie').highcharts({
        //     title:{
        //         text:total,
        //         verticalAlign:'middle',
        //         style:{
        //             lineHeight:"20px"
        //         }
        //     },
        //     chart:{
        //         type:'pie',
        //         backgroundColor:"#EDF2F8"
        //     },
        //     colors:['#00A6E4','#16CDD5',"#5CD8F2","#CCE5EA"],
        //     series:[{
        //         data:[
        //             ['已用',parseFloat(used)],
        //             ['Non Used',parseFloat(nonused)],
        //             ['剩余',parseFloat(remaining)]
        //         ]
        //     }],
        //     plotOptions:{
        //         pie:{
        //             size:'100%',
        //             innerSize:'60%',
        //             dataLabels:{
        //                 enabled: false  
        //             },
        //         }
        //     },
        //     tooltip:{
        //         formatter: function() {
        //             return '<b>'+ this.point.name +'</b>: '+ Highcharts.numberFormat(this.percentage, 1) +'% ('+
        //                 Highcharts.numberFormat(this.y, 2, '.') +' TB)';
        //         }
        //     },
        //     credits: {
        //         enabled: false
        //     }
        // });
        $dfsUsedPercent.html(parseFloat(Highcharts.numberFormat(used, 2, '.')) + "TB");
        $dfsUsedPercent.parent().find('.glyphicon').css('color', '#00A6E4');
        $dfsNonUsedPercent.html(parseFloat(Highcharts.numberFormat(nonused, 2, '.')) + "TB");
        $dfsNonUsedPercent.parent().find('.glyphicon').css('color', '#16CDD5');
        $remainPercent.html(parseFloat(Highcharts.numberFormat(remaining, 2, '.')) + "TB");
        $remainPercent.parent().find('.glyphicon').css('color', '#5CD8F2');

    }
}


;(function() {
    dateRangePicker.Host = Host;
    dateRangePicker.ChnlStream = ChnlStream;
    dateRangePicker.UserCount = UserCount;
    dateRangePicker.Concurrent = Concurrent;
    dateRangePicker.HDFSUseage = HDFSUseage;
    dateRangePicker.HDFSStutas = HDFSStutas;

    dateRangePicker.Host.getCount.call(dateRangePicker);        // 主机属性
    dateRangePicker.ChnlStream.getCount.call(dateRangePicker);  // 录流
    dateRangePicker.UserCount.getData();    // 实时在线用户数量
    dateRangePicker.HDFSUseage.getData();   // HDFS磁盘利用率
    dateRangePicker.HDFSStutas.getData.call(dateRangePicker);   // HDFS状态
    dateRangePicker.Concurrent.getData('total');
    dateRangePicker.Concurrent.bindEvent();

    // setInterval(function(){
    //     dateRangePicker.UserCount.getData();
    //     var reg = $('#chartitle').data('action')
    //     dateRangePicker.Concurrent.getData(reg);
    //     dateRangePicker.HDFSUseage.getData();
    // },60000);
})();
