var DatabaseList = {
	getData:function () {
		//通过Zabbix服务发送请求
		var param0 = new Object();
		param0.search = {
			'key_' : 'zabbix.data[get_mysql_info]'
		}

		ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
			
			var result = data.result;

			for(var i = 0; i < result.length ; i++){

				if(result[i].templateid != '0'){

					var resultArray = result[i].lastvalue.split('#');

				}

			}

			var datebaseArray = new Array();

			for (var i = 0; i < resultArray.length-1; i++) {
				
				var temp = resultArray[i].split('|');

				var datebaseObject = {

					// 主机id
					hostid:temp[0],
					// 主机名
					hostname:temp[1],
					// 主机ip
					hostip:temp[2],
					// 主从关系
					m_s_relation:temp[3],
					// 主从状态
					m_s_status:temp[4],
					// Master_Host
					masterhost:temp[5],
					// 二进制日志
					bin_log:temp[6],
					// Postion
					postion:temp[7],
					// Read_Master_log_pos
					read_log_pos:temp[8],
					// Exec_Master_log_pos
					exec_log_pos:temp[9],
					// 主从延迟
					m_s_delay:temp[10],
					// 连接数
					con_count:temp[11],
					// 数据库数量
					db_count:temp[12]

				}

				datebaseArray.push(datebaseObject);

			}

			DatabaseList.addDom(datebaseArray);

		}, function(data){
		    //token不存在，返回登录
		    goToLogin(DatabaseList);

		})
	},
	getItemIds:function(hostid){
		var param0 = new Object();

		param0.hostids = hostid;
		param0.application = '数据库监控';

		ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
			var result = data.result;

			var itemObject = new Object();
			for (var i = 0; i < result.length; i++) {
				// 发送
				if(result[i].key_ =='mysql.monitor[mysqlstatus_Bytes_sent]'){
					itemObject.senditem = result[i].itemid;
				}
				// 接受
				if(result[i].key_ =='mysql.monitor[mysqlstatus_Bytes_received]'){
					itemObject.receiveditem = result[i].itemid;
				}
				// 查询
				if(result[i].key_ =='mysql.monitor[mysqlstatus_Com_select]'){
					itemObject.selectitem = result[i].itemid;
				}
				// 删除
				if(result[i].key_ =='mysql.monitor[mysqlstatus_Com_delete]'){
					itemObject.deleteitem = result[i].itemid;
				}
				// 更新
				if(result[i].key_ =='mysql.monitor[mysqlstatus_Com_update]'){
					itemObject.updateitem = result[i].itemid;
				}
				// 插入
				if(result[i].key_ =='mysql.monitor[mysqlstatus_Com_insert]'){
					itemObject.insertitem = result[i].itemid;
				}
			}

			var itemids = [itemObject.senditem,itemObject.receiveditem,itemObject.selectitem,itemObject.deleteitem,itemObject.updateitem,itemObject.insertitem];

			dateRangePicker.Speed.getData(itemids);
			dateRangePicker.CURD.getData(itemids);
		});
	},
	/**
	 * 获取数据（已废弃，有参考价值）
	 * @param  {[type]} itemids [description]
	 * @return {[type]}         [description]
	 */
	getHistory:function(itemids){
		var param0 = new Object();

		param0.itemids = itemids;
		param0.time_from = moment().add(-15,'minutes').format('X');
		param0.time_till = moment().format('X');
		param0.history = 3;
		param0.limit = '';

		var sendArray = new Array(),			// 发送数据
			receivedArray = new Array(),		// 接受数据
			selectArray = new Array(),			// 查询数据
			deleteArray = new Array(),			// 删除数据
			updateArray = new Array(),			// 更新数据
			insertArray = new Array();			// 插入数据

		ZabbixServer.sendAjaxRequest("history.get", param0, function (data) {
			var result = data.result;

			for (var i = 0; i < result.length; i++) {

				// 发送数据
				if(result[i].itemid == itemids[0]){
					sendArray.push([parseInt(result[i].clock) * 1000, parseFloat(result[i].value)]);
				}

				// 接受数据
				if(result[i].itemid == itemids[1]){
					receivedArray.push([parseInt(result[i].clock) * 1000, parseFloat(result[i].value)]);
				}

				// 查询数据
				if(result[i].itemid == itemids[2]){
					selectArray.push([parseInt(result[i].clock) * 1000, parseFloat(result[i].value)]);
				}

				// 删除数据
				if(result[i].itemid == itemids[3]){
					deleteArray.push([parseInt(result[i].clock) * 1000, parseFloat(result[i].value)]);
				}

				// 更新数据
				if(result[i].itemid == itemids[4]){
					updateArray.push([parseInt(result[i].clock) * 1000, parseFloat(result[i].value)]);
				}
				
				// 插入数据
				if(result[i].itemid == itemids[5]){
					insertArray.push([parseInt(result[i].clock) * 1000, parseFloat(result[i].value)]);
				}

			}

			DatabaseList.render(0,[sendArray,receivedArray]);
			DatabaseList.render(1,[selectArray,deleteArray,updateArray,insertArray]);

		});

	},
	addDom:function(dbArray){

		// 清空
		var $streamList = $('#streamList');
		$streamList.find('tobdy tr').remove();

		var dom ='';
		for (var i = 0; i < dbArray.length; i++) {
			
			var domclass = "";
	
			if(i == 0){
				domclass = "active";
				DatabaseList.getItemIds(+dbArray[i].hostid);
			}

			dom +='<tr class="'+domclass+'" data-hostid="'+dbArray[i].hostid+'">' +
	            '<td scope="row" width="80" class="text-center">'+GlobalUtil.getLineNumber(i+1)+'</td>' +
	            '<td>'+dbArray[i].hostname+'</td>' +
	            '<td >'+dbArray[i].hostip+'</td>' +
	            '<td width="100">'+dbArray[i].m_s_relation+'</td>' +
	            '<td class="text-center">'+dbArray[i].m_s_status+'</td>' +
	            '<td >'+dbArray[i].masterhost+'</td>' +
	            '<td width="100" class="text-center">'+dbArray[i].m_s_delay+'</td>' +
	            '<td width="100" class="text-center">'+dbArray[i].con_count+'</td>' +
	            '<td width="120" class="text-center">'+dbArray[i].db_count+'</td>' +
	            '<td width="100" class="text-center"><a href="db_detail.html?data='+dbArray[i].hostid+'" class="label label-success">详情</a></td>' +
	        '</tr>';
			
		}

		$streamList.find('tbody').append(dom);

		DatabaseList.bindEvent();
	},

	bindEvent:function(){
		$('#streamList').off('click','tbody tr');
		$('#streamList').on('click','tbody tr',function(){
			var $this = $(this);

			$('#streamList').find('tr').removeClass('active');

			$this.addClass('active');

			var hostid = $(this).data('hostid');
				chnlname = $(this).find('td').eq(1).html();

			$('.dbname').eq(0).html(chnlname+"接受/发送速率表");
			$('.dbname').eq(1).html(chnlname+"每秒平均操作数曲线");
		    
		    DatabaseList.getItemIds(hostid);
		});
	},
	render:function(type,series){
		
		switch(type){
			case 0 :drawSpeed(series);break;
			case 1 :drawOpration(series);break;
		}

		function drawSpeed(series){
			Highcharts.setOptions({
			    global: {
			        useUTC: false
			    }
			});
			

			$('#Speed').highcharts({
			    credits: {
			        text: '',
			        href: '',
			        enabled: false 
			    },
			    chart: {
			        zoomType: 'x',
			        backgroundColor:"#EDF2F8"
			    },
			    colors:["#E87F69","#9020CB"],
			    title: {
			        text: ''
			    },
			    xAxis: {
	                labels: {  
	                    formatter: function() {  
	                        var vDate=moment(this.value);
	                        return (dateRangePicker.Speed.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
	                    }
	                },
	                title: {
	                    text: null
	                }
			    },
			    yAxis: {
			        title:{
			            text:''
			        }
			    },
			    tooltip: {
			        formatter:function(){
			            return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+'：<b>' +GlobalUtil.getSize(this.y) +'/s</b>';
			        }
			    },
			    legend: {
			        enabled: false
			    },
			    plotOptions: {
			        line: {
			            lineWidth: 1,
			            marker: {
			                enabled: false
			            },
			            shadow: false,
			            states: {
			                hover: {
			                    lineWidth: 1
			                }
			            }
			        }
			    },

			    series: [{
			        type:'line',
			        name: "发送速率",
			        data: series[0]
			    }, {
			        type:'line',
			        name: "接收速率",
			        data: series[1]
			    }]
			}); 
		}
		function drawOpration(series){
			Highcharts.setOptions({
			    global: {
			        useUTC: false
			    }
			});
			

			$('#CURD').highcharts({
			    credits: {
			        text: '',
			        href: '',
			        enabled: false 
			    },
			    chart: {
			        zoomType: 'x',
			        backgroundColor:"#EDF2F8"
			    },
			    colors:["#E87F69","#9020CB","#FF7300","#17BD44"],
			    title: {
			        text: ''
			    },
			    xAxis: {
	                labels: {  
	                    formatter: function() {  
	                        var vDate=moment(this.value);
	                        return (dateRangePicker.CURD.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
	                    }
	                },
	                title: {
	                    text: null
	                }
			    },
			    yAxis: {
			        title:{
			            text:''
			        }
			    },
			    tooltip: {
			        formatter:function(){
			            return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+'：<b>' +this.y+'</b>';
			        }
			    },
			    legend: {
			        enabled: false
			    },
			    plotOptions: {
			        line: {
			            lineWidth: 1,
			            marker: {
			                enabled: false
			            },
			            shadow: false,
			            states: {
			                hover: {
			                    lineWidth: 1
			                }
			            }
			        }
			    },

			    series: [{
			        type:'line',
			        name: "查询操作数",
			        data: series[0]
			    }, {
			        type:'line',
			        name: "删除操作数",
			        data: series[1]
			    }, {
			        type:'line',
			        name: "更新操作数",
			        data: series[2]
			    }, {
			        type:'line',
			        name: "插入操作数",
			        data: series[3]
			    }]
			}); 
		}
	}
}

var Speed = {
	getData: function(itemids) {
		var _this = this;
		dateRangePicker.argsCache("Speed", { itemids: itemids });
		itemids = _this.argsCache.itemids;

        dateRangePicker.init("Speed");

		var param0 = new Object();
		param0.itemids = itemids;
		param0.time_from = _this.fromUnix || moment().add(-15,'minutes').format('X');
		param0.time_till = _this.toUnix || moment().format('X');
		param0[_this.methodType] = 3;
		param0.limit = '';

		var sendArray = new Array(),			// 发送数据
			receivedArray = new Array();		// 接受数据

		ZabbixServer.sendAjaxRequest(_this.methodType + ".get", param0, function (data) {
			var result = data.result;

			for (var i = 0; i < result.length; i++) {

				// 发送数据
				if(result[i].itemid == itemids[0]){
					sendArray.push([parseInt(result[i].clock) * 1000, parseFloat(result[i].value || result[i].value_avg)]);
				}

				// 接受数据
				if(result[i].itemid == itemids[1]){
					receivedArray.push([parseInt(result[i].clock) * 1000, parseFloat(result[i].value || result[i].value_avg)]);
				}

			}
			DatabaseList.render(0,[sendArray,receivedArray]);

		});
	}
}

var CURD = {
	getData: function(itemids) {
		var _this = this;
		dateRangePicker.argsCache("CURD", { itemids: itemids });
		itemids = _this.argsCache.itemids;

        dateRangePicker.init("CURD");

		var param0 = new Object();

		param0.itemids = itemids;
		param0.time_from = _this.fromUnix || moment().add(-15,'minutes').format('X');
		param0.time_till = _this.toUnix || moment().format('X');
		param0[_this.methodType] = 3;
		param0.limit = '';

		var selectArray = new Array(),			// 查询数据
			deleteArray = new Array(),			// 删除数据
			updateArray = new Array(),			// 更新数据
			insertArray = new Array();			// 插入数据

		ZabbixServer.sendAjaxRequest(_this.methodType + ".get", param0, function (data) {
			var result = data.result;

			for (var i = 0; i < result.length; i++) {

				// 查询数据
				if(result[i].itemid == itemids[2]){
					selectArray.push([parseInt(result[i].clock) * 1000, parseFloat(result[i].value || result[i].value_avg)]);
				}

				// 删除数据
				if(result[i].itemid == itemids[3]){
					deleteArray.push([parseInt(result[i].clock) * 1000, parseFloat(result[i].value || result[i].value_avg)]);
				}

				// 更新数据
				if(result[i].itemid == itemids[4]){
					updateArray.push([parseInt(result[i].clock) * 1000, parseFloat(result[i].value || result[i].value_avg)]);
				}
				
				// 插入数据
				if(result[i].itemid == itemids[5]){
					insertArray.push([parseInt(result[i].clock) * 1000, parseFloat(result[i].value || result[i].value_avg)]);
				}

			}

			DatabaseList.render(1,[selectArray,deleteArray,updateArray,insertArray]);

		});
	}
}
;(function(){
	dateRangePicker.Speed = Speed;
	dateRangePicker.CURD = CURD;
	DatabaseList.getData();
})();