var itemid = window.location.search.split('=')[1];

var StreamDetail = {
	getData:function(){
		var param0 = new Object();
		param0.itemids = itemid;
		param0.time_from = moment().add(-15,'minutes').format('X');
		param0.time_till = moment().format('X');

		ZabbixServer.sendAjaxRequest("history.get", param0, function (data) {
		    //通过主机列表获取主机的各项数据
		    var datalist = data.result;
		    var series = new Array();

		    for (var i = 0; i < datalist.length; i++) {
		    	series.push([parseInt(datalist[i].clock) * 1000, parseInt(datalist[i].value)]);
		    }

		    StreamDetail.render(series);
		}, function(data){
		    //token不存在，返回登录
		    goToLogin();

		})
	},
	render:function(series){
		Highcharts.setOptions({
            global: {
                useUTC: false
            }
        });
        
        $('.dataChart').highcharts({
            credits: {
                text: '',
                href: '',
                enabled: false 
            },
            chart: {
                zoomType: 'x',
                type:'line',
                backgroundColor:"#EDF2F8"
            },
            colors:["#00B8EA",'#F27D41'],
            title: {
                text: ''
            },
            xAxis: {
                labels: {  
                    formatter: function() {  
                        var vDate=moment(this.value);  
                        return (vDate.format('HH:mm'));  
                    }
                },
                title: {
                    text: null
                }
            },
            yAxis: {
                title: {
                    text: ''
                }
            },
            tooltip: {
                formatter:function(){
                    return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+':<b>' + GlobalUtil.getSize(this.y)+'</b>';
                }
            },
            legend: {
                enabled: false
            },
            plotOptions: {
                line: {
                    lineWidth: 1,
                    marker: {
                        enabled: false
                    },
                    shadow: false,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    },
                }
            },

            series: [{
                type: 'line',
                name: '流入',
                data: series
            }]
        });
	}
}

;(function(){
	StreamDetail.getData();
})();