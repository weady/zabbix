// 获取hostid
var HOSTID = window.location.search.split('&')[0].split('=')[1];
var HOSTNAME = window.location.search.split('&')[1].split('=')[1];
// 初始化导航条
Nav.init(HOSTID,HOSTNAME);
$('.hostname').html(HOSTNAME);

var Disk = {
    init: function() {
        // 获取磁盘，初始化下拉列表
        var param = new Object();
        param.hostids = HOSTID;
        param.application = "Disk IO 状态";

        //通过Zabbix服务发送请求
        //获取磁盘Utils利用率的数据，并绘图
        ZabbixServer.sendAjaxRequest("item.get", param, function(data) {

            // 对比key_值,获得itemid
            var iTemData = data.result;
            var Items = new Object();

            for (var i = 0; i < iTemData.length; i++) {

                // cpu iowait time
                if (iTemData[i].key_ == "baseinfo[disk_name]") {
                    Items.nameItem = iTemData[i].lastvalue;
                }

            }

            var namearray = Items.nameItem.split(" ");
            var selectDom = "";
            for (var i = 0; i < namearray.length; i++) {
                selectDom += '<option value="' + namearray[i] + '">' + namearray[i] + '</option>'
            }

            $('.disk_select').append(selectDom);
            $('.disk_select').append(selectDom);

            Disk.getData(0);
            Disk.getData(1);
            Disk.getData(2);
            Disk.bindEvent();
        }, function(data) {
            //token不存在，返回登录
            goToLogin();
        });
    },
    /**
     * 获取数据
     * @param  {string} datasource 数据源
     * @return {[type]} 执行回调
     */
    getData: function(datasource, callback) {

        switch (datasource) {
            case 0:
                // 获取磁盘Uitl利用率数据
                dateRangePicker.DiskPused.getData(); 
                break;
            case 1:
                // 获取速率数据
                dateRangePicker.IOSpeed.getData();
                break;
            case 2:
                // 获取各状态
                getStatusData();
                break;
        }

        // 获取各状态数据
        function getStatusData(){
            var param0 = new Object();
            param0.application = "文件系统大小状态";
            param0.hostids = HOSTID;

            //通过Zabbix服务发送请求
            ZabbixServer.sendAjaxRequest("item.get", param0, function(data) {

                // 对比key_值,获得itemid
                var iTemData = data.result;
                var Items = new Object();

                for (var i = 0; i < iTemData.length; i++) {

                    // BOOT总大小
                    if (iTemData[i].key_ == "vfs.fs.size[/boot,total]") {
                        Items.bootTotal = parseInt(iTemData[i].lastvalue);
                    }
                    // BOOT已用大小
                    if (iTemData[i].key_ == "vfs.fs.size[/boot,used]") {
                        Items.bootUsed = parseInt(iTemData[i].lastvalue);
                    }
                    // BOOT空闲大小
                    if (iTemData[i].key_ == "vfs.fs.size[/boot,free]") {
                        Items.bootFree = parseInt(iTemData[i].lastvalue);
                    }

                    // HOME总大小
                    if (iTemData[i].key_ == "vfs.fs.size[/home,total]") {
                        Items.homeTotal = parseInt(iTemData[i].lastvalue);
                    }
                    // HOME已用大小
                    if (iTemData[i].key_ == "vfs.fs.size[/home,used]") {
                        Items.homeUsed = parseInt(iTemData[i].lastvalue);
                    }
                    // HOME空闲大小
                    if (iTemData[i].key_ == "vfs.fs.size[/home,free]") {
                        Items.homeFree = parseInt(iTemData[i].lastvalue);
                    }

                    // USR总大小
                    if (iTemData[i].key_ == "vfs.fs.size[/usr,total]") {
                        Items.usrTotal = parseInt(iTemData[i].lastvalue);
                    }
                    // USR已用大小
                    if (iTemData[i].key_ == "vfs.fs.size[/usr,used]") {
                        Items.usrUsed = parseInt(iTemData[i].lastvalue);
                    }
                    // USR空闲大小
                    if (iTemData[i].key_ == "vfs.fs.size[/usr,free]") {
                        Items.usrFree = parseInt(iTemData[i].lastvalue);
                    }
                    // VAR 总大小
                    if (iTemData[i].key_ == "vfs.fs.size[/var,total]") {
                        Items.varTotal = parseInt(iTemData[i].lastvalue);
                    }
                    // VAR 已用大小
                    if (iTemData[i].key_ == "vfs.fs.size[/var,used]") {
                        Items.varUsed = parseInt(iTemData[i].lastvalue);
                    }
                    // VAR 空闲大小
                    if (iTemData[i].key_ == "vfs.fs.size[/var,free]") {
                        Items.varFree = parseInt(iTemData[i].lastvalue);
                    }
                    // WORK 总大小
                    if (iTemData[i].key_ == "vfs.fs.size[/work,total]") {
                        Items.workTotal = parseInt(iTemData[i].lastvalue);
                    }
                    // WORK 已用大小
                    if (iTemData[i].key_ == "vfs.fs.size[/work,used]") {
                        Items.workUsed = parseInt(iTemData[i].lastvalue);
                    }
                    // WORK 空闲大小
                    if (iTemData[i].key_ == "vfs.fs.size[/work,free]") {
                        Items.workFree = parseInt(iTemData[i].lastvalue);
                    }
                }

                Chart.render(2,Items);
            });
        }
    },
    // 绑定事件
    bindEvent: function() {
        $(document).on('change', '#diskUtil', function() {
            // $('#readWrite').val($(this).val());
            Disk.getData(0);
            // Disk.getData(1);
        })
        $(document).on('change', '#readWrite', function() {
            // $('#diskUtil').val($(this).val());
            // Disk.getData(0);
            Disk.getData(1);
        })
    }
}

// 获取磁盘Util利用率
var DiskPused = {
    getData: function() {
        var _this = this;
        dateRangePicker.init("DiskPused");

        var name = $("#diskUtil").val();
        var key = "disk.resource[" + name + ",util]";

        var param0 = new Object();
        param0.application = "Disk IO 状态";
        param0.hostids = HOSTID;

        //通过Zabbix服务发送请求
        ZabbixServer.sendAjaxRequest("item.get", param0, function(data) {

            // 对比key_值,获得itemid
            var iTemData = data.result;
            var Items = new Object();

            for (var i = 0; i < iTemData.length; i++) {

                // 磁盘使用率
                if (iTemData[i].key_ == key) {
                    Items.usedItem = iTemData[i].itemid;
                }

            }

            var param1 = new Object();

            param1.itemids = [Items.usedItem];
            param1.hostids = HOSTID;
            param1[_this.methodType] = 0;
            param1.time_from = _this.fromUnix || moment().add(-15, 'minutes').format('X');
            param1.time_till = _this.toUnix || moment().format('X');
            param1.limit = '';

            var diskUesdData = new Array();

            // 获取history历史数据
            ZabbixServer.sendAjaxRequest(_this.methodType + ".get", param1, function(data) {

                var historyData = data.result;

                for (var i = 0; i < historyData.length; i++) {

                    // 对比itemid 将数据push到对应的数组
                    if (historyData[i].itemid == Items.usedItem) {
                        diskUesdData.push([parseInt(historyData[i].clock) * 1000, parseInt(historyData[i].value || historyData[i].value_avg)]);
                    }

                }

                Chart.render(0, diskUesdData);

            });

        }, function(data) {

            //token不存在，返回登录
            goToLogin();

        });
    }
}

// 获取IO读写速率数据
var IOSpeed = {
    getData: function() {
        var _this = this;
        dateRangePicker.init("IOSpeed");

        var name = $("#readWrite").val();
        var keyread = "disk.resource[" + name + ",read_sectors]";
        var keywrite = "disk.resource[" + name + ",write_sectors]";

        var param0 = new Object();
        param0.application = "Disk IO 状态";
        param0.hostids = HOSTID;

        //通过Zabbix服务发送请求
        ZabbixServer.sendAjaxRequest("item.get", param0, function(data) {

            // 对比key_值,获得itemid
            var iTemData = data.result;
            var Items = new Object();

            for (var i = 0; i < iTemData.length; i++) {

                // 读速率
                if (iTemData[i].key_ == keyread) {
                    Items.readItem = iTemData[i].itemid;
                }

                // 写速率
                if (iTemData[i].key_ == keywrite) {
                    Items.writeItem = iTemData[i].itemid;
                }

            }

            var param1 = new Object();

            param1.itemids = [Items.readItem, Items.writeItem];
            param1.hostids = HOSTID;
            param1[_this.methodType] = 3;
            param1.time_from = _this.fromUnix || moment().add(-15, 'minutes').format('X');
            param1.time_till = _this.toUnix || moment().format('X');
            param1.limit = '';

            var readData = new Array();
            var writeData = new Array();

            // 获取history历史数据
            ZabbixServer.sendAjaxRequest(_this.methodType + ".get", param1, function(data) {

                var historyData = data.result;

                for (var i = 0; i < historyData.length; i++) {

                   
                    // 对比itemid 将数据push到对应的数组
                    if (historyData[i].itemid == Items.readItem) {
                        readData.push([parseInt(historyData[i].clock) * 1000, parseInt(historyData[i].value || historyData[i].value_avg)]);
                    }

                    if (historyData[i].itemid == Items.writeItem) {
                        writeData.push([parseInt(historyData[i].clock) * 1000, parseInt(historyData[i].value || historyData[i].value_avg)]);
                    }
                }

                var series = [readData, writeData];

                Chart.render(1, series);

            });
        });
    }
}

// 图表绘制器
var Chart = {
    // 绘图分发器
    render: function(type, series) {
        switch (type) {
            case 0:
                Chart.drawUtil(series);
                break;
            case 1:
                Chart.drawReadAnWrite(series);
                break;
            case 2:
                Chart.drawPie(series);
                break;
        }
    },
    // 绘制磁盘util利用率
    drawUtil: function(series) {
        Highcharts.setOptions({
            global: {
                useUTC: false
            }
        });
        
        $('#DiskPused').highcharts({
            credits: {
                text: '',
                href: '',
                enabled: false 
            },
            chart: {
                zoomType: 'x',
                type:'line',
                backgroundColor:"#EDF2F8"
            },
            colors:["#00B6E7"],
            title: {
                text: ''
            },
            xAxis: {
                labels: {  
                    formatter: function() {  
                        var vDate=moment(this.value);
                        return (dateRangePicker.DiskPused.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                    }
                },
                title: {
                    text: null
                }
            },
            yAxis: {
                title: {
                    text: ''
                },
                labels: {
                    format: '{value} %'
                }
            },
            tooltip: {
                shared: true,
                formatter:function(){
                    return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>util利用率：<b>' + this.y+'%</b>';
                }
            },
            legend: {
                enabled: false
            },
            plotOptions: {
                area: {
                    fillColor: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1},
                        stops: [
                            [0, "#00B6E7"],
                            [1, Highcharts.Color("#00B6E7").setOpacity(0).get('rgba')]
                        ]
                    },
                    lineWidth: 1,
                    marker: {
                        enabled: false
                    },
                    shadow: false,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    },
                }
            },

            series: [{
                type: 'area',
                name: 'value',
                data: series
            }]
        });  
    },
    drawReadAnWrite: function(series) {
        
        Highcharts.setOptions({
            global: {
                useUTC: false
            }
        });
        

        $('#IOSpeed').highcharts({
            credits: {
                text: '',
                href: '',
                enabled: false 
            },
            chart: {
                zoomType: 'x',
                backgroundColor:"#EDF2F8"
            },
            colors:["#E87F69","#9020CB"],
            title: {
                text: ''
            },
            xAxis: {
                labels: {  
                    formatter: function() {  
                        var vDate=moment(this.value);
                        return (dateRangePicker.IOSpeed.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                    }
                },
                title: {
                    text: null
                }
            },
            yAxis: {
                title:{
                    text:''
                }
            },
            tooltip: {
                formatter:function(){
                    return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+'：<b>' +GlobalUtil.getSize(this.y) +'/s</b>';
                }
            },
            legend: {
                enabled: false
            },
            plotOptions: {
                line: {
                    lineWidth: 1,
                    marker: {
                        enabled: false
                    },
                    shadow: false,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    }
                }
            },

            series: [{
                type:'line',
                name: "读速率",
                data: series[0]
            }, {
                type:'line',
                name: "写速率",
                data: series[1]
            }]
        }); 


    },
    drawPie:function(series){

        $('.bootTotal').html(GlobalUtil.getSize(series.bootTotal));
        $('.bootUsed').html(GlobalUtil.getSize(series.bootUsed));
        $('.bootFree').html(GlobalUtil.getSize(series.bootFree));
        $('.pieCell').eq(0).highcharts({
            title:{
                text:"/BOOT",
                verticalAlign:'middle',
                style:{
                    lineHeight:"20px"
                }

            },
            chart:{
                type:'pie',
                backgroundColor:"#EDF2F8"
            },
            colors:['#05B997','#CDE4E9'],
            series:[{
                data:[
                    ['空闲',series.bootFree],
                    ['已用',series.bootUsed]
                ]
            }],
            tooltip: {
                formatter:function(){
                    return this.key+':'+Highcharts.numberFormat(this.percentage,2,'.')+"%"
                }
            },
            plotOptions:{
                pie:{
                    size:110,
                    innerSize:'90',
                    dataLabels:{
                        enabled: false  
                    },
                }
            },
            credits: {
                enabled: false
            }
        });

        $('.homeTotal').html(GlobalUtil.getSize(series.homeTotal));
        $('.homeUsed').html(GlobalUtil.getSize(series.homeUsed));
        $('.homeFree').html(GlobalUtil.getSize(series.homeFree));
        $('.pieCell').eq(1).highcharts({
            title:{
                text:"/HOME",
                verticalAlign:'middle',
                style:{
                    lineHeight:"20px"
                }

            },
            chart:{
                type:'pie',
                backgroundColor:"#EDF2F8"
            },
            colors:['#3CB5CD','#CADCEC'],
            series:[{
                data:[
                    ['空闲',series.homeFree],
                    ['已用',series.homeUsed]
                ]
            }],
            tooltip: {
                formatter:function(){
                    return this.key+':'+Highcharts.numberFormat(this.percentage,2,'.')+"%"
                }
            },
            plotOptions:{
                pie:{
                    size:110,
                    innerSize:'90',
                    dataLabels:{
                        enabled: false  
                    },
                }
            },
            credits: {
                enabled: false
            }
        });

        $('.usrTotal').html(GlobalUtil.getSize(series.usrTotal));
        $('.usrUsed').html(GlobalUtil.getSize(series.usrUsed));
        $('.usrFree').html(GlobalUtil.getSize(series.usrFree));
        $('.pieCell').eq(2).highcharts({
            title:{
                text:"/USR",
                verticalAlign:'middle',
                style:{
                    lineHeight:"20px"
                }

            },
            chart:{
                type:'pie',
                backgroundColor:"#EDF2F8"
            },
            colors:['#336ACE','#CDD3EA'],
            series:[{
                data:[
                    ['空闲',series.usrFree],
                    ['已用',series.usrUsed]
                ]
            }],
            tooltip: {
                formatter:function(){
                    return this.key+':'+Highcharts.numberFormat(this.percentage,2,'.')+"%"
                }
            },
            plotOptions:{
                pie:{
                    size:110,
                    innerSize:'90',
                    dataLabels:{
                        enabled: false  
                    },
                }
            },
            credits: {
                enabled: false
            }
        });

        $('.varTotal').html(GlobalUtil.getSize(series.varTotal));
        $('.varUsed').html(GlobalUtil.getSize(series.varUsed));
        $('.varFree').html(GlobalUtil.getSize(series.varFree));
        $('.pieCell').eq(3).highcharts({
            title:{
                text:"/VAR",
                verticalAlign:'middle',
                style:{
                    lineHeight:"20px"
                }

            },
            chart:{
                type:'pie',
                backgroundColor:"#EDF2F8"
            },
            colors:['#9022CA','#E2D9E8'],
            series:[{
                data:[
                    ['空闲',series.varTotal],
                    ['已用',series.varUsed]
                ]
            }],
            tooltip: {
                formatter:function(){
                    return this.key+':'+Highcharts.numberFormat(this.percentage,2,'.')+"%"
                }
            },
            plotOptions:{
                pie:{
                    size:110,
                    innerSize:'90',
                    dataLabels:{
                        enabled: false  
                    },
                }
            },
            credits: {
                enabled: false
            }
        });

        $('.workTotal').html(GlobalUtil.getSize(series.workTotal));
        $('.workUsed').html(GlobalUtil.getSize(series.workUsed));
        $('.workFree').html(GlobalUtil.getSize(series.workFree));
        $('.pieCell').eq(4).highcharts({
            title:{
                text:"/WORK",
                verticalAlign:'middle',
                style:{
                    top:'100px'
                }
            },
            chart:{
                type:'pie',
                backgroundColor:"#EDF2F8"
            },
            colors:['#F3827D','#EADCDA'],
            series:[{
                data:[
                    ['空闲',series.workFree],
                    ['已用',series.workUsed]
                ]
            }],
            tooltip: {
                formatter:function(){
                    return this.key+':'+Highcharts.numberFormat(this.percentage,2,'.')+"%"
                }
            },
            plotOptions:{
                pie:{
                    size:110,
                    innerSize:'90',
                    dataLabels:{
                        enabled: false  
                    },
                }
            },
            credits: {
                enabled: false
            }
        });
    }
}

;
(function() {
    dateRangePicker.Disk = Disk;
    dateRangePicker.DiskPused = DiskPused;
    dateRangePicker.IOSpeed = IOSpeed;
    dateRangePicker.Chart = Chart;
    dateRangePicker.Disk.init();
})();
