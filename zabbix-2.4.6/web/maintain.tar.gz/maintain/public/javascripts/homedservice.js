// 获取hostid
var HOSTID = window.location.search.split('&')[0].split('=')[1];
var HOSTNAME = window.location.search.split('&')[1].split('=')[1];
// 初始化导航条
Nav.init(HOSTID,HOSTNAME);
$('.hostname').html(HOSTNAME);
// 进程对象
var Progress = {
	// 获取数据
	getData:function () {
		var param0 = new Object();
		param0.application = "进程状态";
		param0.search = {
			'key_':"baseinfo[process]"
		};
		param0.hostids = HOSTID; 

		ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
		    //通过主机列表获取主机的各项数据
		    
		    var progressName = data.result[0].lastvalue.split('|');

		    Progress.getDetail(progressName);

		}, function(data){
		    //token不存在，返回登录
		    goToLogin();

		})
	},
	// 根据服务名获取每一个服务的数据
	getDetail:function(progressName){

		var dataArray = new Array();


		for (var i = 0; i < progressName.length; i++) {
			var progress = new Object();
			progress.name =  progressName[i];

			dataArray.push(progress);
		}

		// api状态和进程状态
		var param2 = new Object();
		param2.hostids = HOSTID;
		param2.application = "进程状态";

		ZabbixServer.sendAjaxRequest("item.get", param2, function (data) {
			
			var datas = data.result;

			for (var i = 0; i < dataArray.length; i++) {
			
				for (var j = 0; j < datas.length; j++) {
					// 内存占用量
					if(datas[j].key_ == 'process.value['+dataArray[i].name+',mem]'){
						dataArray[i].memused = datas[j].lastvalue; 
					}
					// 内存利用率
					if(datas[j].key_ == 'process.value['+dataArray[i].name+',pmem]'){
						dataArray[i].mempused = datas[j].lastvalue;
						dataArray[i].memitem = datas[j].itemid; 
					}

					// cpu利用率
					if(datas[j].key_ == 'process.value['+dataArray[i].name+',cpu]'){
						dataArray[i].cpupused = datas[j].lastvalue; 
						dataArray[i].cpuitem = datas[j].itemid; 
					}

					// 服务状态
					if(datas[j].key_ == 'process.value['+dataArray[i].name+',stat]'){
						dataArray[i].servicestatus = datas[j].lastvalue; 
					}
				}
			}

			// 进程表
			Progress.addDom(dataArray);

			// 
			Progress.getMemPused(dataArray[0].memitem);
			Progress.getCPUPused(dataArray[0].cpuitem);
			Progress.initSelect(dataArray);

			// // CPU利用率
			// var param3 = new Object();
			// param3.hostids = HOSTID;
			// param3.application = "Homed 服务CPU使用情况";

			// ZabbixServer.sendAjaxRequest("item.get", param3, function (data) {
				
			// 	var datas = data.result;

			// 	for (var i = 0; i < dataArray.length; i++) {
				
			// 		for (var j = 0; j < datas.length; j++) {
						
			// 			// cpu itemid
			// 			if(datas[j].key_ == 'homed.resource['+dataArray[i].name+',cpu]'){
			// 				dataArray[i].cpuitem = datas[j].itemid; 
			// 			}
			// 		}
			// 	}

			// 	// CPU利用率
			// 	Progress.getCPUPused(dataArray[0].cpuitem);

			// 	

			// });

		});

	},
	// 表格添加行
	addDom:function(data){
		$('#progressStatus').find('tbody').children().remove();
		var dom ='';
		for (var i = 0; i < data.length; i++) {
			dom +='<tr>' +
                '<td>'+i+'</td>' +
                '<td>'+data[i].name+'</td>' +
                '<td>'+GlobalUtil.getSize(data[i].memused)+'</td>' +
                '<td>'+toFixed(data[i].mempused,2)+'%</td>' +
                '<td>'+toFixed(data[i].cpupused,2)+'%</td>' +
                '<td>'+data[i].servicestatus+'</td>' +
            '</tr>';
		}

		$('#progressStatus').find('tbody').append(dom);
		dateRangePicker.apacheStatus.getData();
	},
	// 初始化下拉列表
	initSelect:function(data){
		$('#memselect').children().remove();
		$('#cpuselect').children().remove();

		var dom_cpu = "",
			dom_mem = '';

		for (var i = 0; i < data.length; i++) {
			dom_mem+='<option value="'+data[i].name+'">'+data[i].name+'</option>';
			dom_cpu+='<option value="'+data[i].name+'">'+data[i].name+'</option>';
		}

		$('#memselect').append(dom_mem);
		$('#cpuselect').append(dom_cpu);

		Progress.bindEvent(data);
	},
	// 获取内存利用率
	getMemPused:function(itemid){
		return dateRangePicker.MemPused.getData(itemid);
	},
	// 获取CPU利用率
	getCPUPused:function(itemid){
		return dateRangePicker.CPUPused.getData(itemid);
	},
	bindEvent:function(data){
		$(document).on('change','#memselect',function(){
			var $self = $(this);
			$('#cpuselect').val($self.val());

			for (var i = 0; i < data.length; i++) {
				if(data[i].name == $self.val()){
					Progress.getMemPused(data[i].memitem);
					Progress.getCPUPused(data[i].cpuitem);
				}
			}
		});
		$(document).on('change','#cpuselect',function(){
			var $self = $(this);
			$('#memselect').val($self.val());

			for (var i = 0; i < data.length; i++) {
				if(data[i].name == $self.val()){
					Progress.getMemPused(data[i].memitem);
					Progress.getCPUPused(data[i].cpuitem);
				}
			}
		});
	},
	render:function(type,series){
		switch(type){
			// cpu利用率
			case 0: Chart.drawCPU(series);break;
			// 内存利用率
			case 1: Chart.drawMem(series);break;
		}
	}
}
// 获取CPU利用率
var CPUPused = {
	getData: function(itemid){
		var _this = this;
		dateRangePicker.argsCache("CPUPused", { itemid: itemid });
		itemid = this.argsCache.itemid;

        dateRangePicker.init("CPUPused");

		var param0 = new Object();
		param0.itemids = itemid;
		param0[_this.methodType] = 0;
		param0.hostids = HOSTID;
		param0.time_from = _this.fromUnix || moment().add(-15,'minutes').format('X');
		param0.time_till = _this.toUnix || moment().format('X');

		ZabbixServer.sendAjaxRequest(_this.methodType + ".get", param0, function (data) {
			// CPU利用率
			var datas = data.result;
			var series = new Array();

			for (var i = 0; i < datas.length; i++) {
				series.push([parseInt(datas[i].clock) * 1000, parseFloat(datas[i].value || datas[i].value_avg)]);
			}

			Progress.render(0,series);

		});
	},
}
// 获取内存利用率
var MemPused = {
	getData: function(itemid){
		var _this = this;
		dateRangePicker.argsCache("MemPused", { itemid: itemid });
		itemid = _this.argsCache.itemid;

        dateRangePicker.init("MemPused");

		var param0 = new Object();
		param0.itemids = itemid;
		param0[_this.methodType] = 0;
		param0.hostids = HOSTID;
		param0.time_from = _this.fromUnix || moment().add(-15,'minutes').format('X');
		param0.time_till = _this.toUnix || moment().format('X');

		ZabbixServer.sendAjaxRequest(_this.methodType + ".get", param0, function (data) {
			// CPU利用率
			var datas = data.result;
			var series = new Array();

			for (var i = 0; i < datas.length; i++) {
				series.push([parseInt(datas[i].clock) * 1000, parseFloat(datas[i].value || datas[i].value_avg)]);
			}

			Progress.render(1,series);

		});
	},
}
// 获取Apache状态
var apacheStatus = {
	getData: function() {
		var param0 = {
			application: 'Homed 进程状态',
			search: {
				'key_': 'homed.status[httpd,status]'
			},
			hostids: HOSTID
		};
		ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
			var apacheStatusStr = data.result[0].lastvalue;
			if(apacheStatusStr !== '0') {
				var apacheStatus = apacheStatusStr.split(' ')[1];
				var $progressStatus = $('#progressStatus').find('tbody');
				var sort = +$progressStatus.find('tr:last td:first').text();
				$progressStatus.append('<tr><td>' + ++sort + '</td><td>apache</td><td>-</td><td>-</td><td>-</td><td>' + apacheStatus + '</td></tr>')
			}
		});
	}
}
// 图形绘制对象
var Chart = {
	// 绘制CPU利用率
	drawCPU:function(series){
		Highcharts.setOptions({
		    global: {
		        useUTC: false
		    }
		});
		
		$('#CPUPused').highcharts({
		    credits: {
		        text: '',
		        href: '',
		        enabled: false 
		    },
		    chart: {
		        zoomType: 'x',
		        type:'line',
		        backgroundColor:"#EDF2F8"
		    },
		    colors:["#00B6E7"],
		    title: {
		        text: ''
		    },
		    xAxis: {
                labels: {  
                    formatter: function() {  
                        var vDate=moment(this.value);
                        return (dateRangePicker.CPUPused.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                    }
                },
                title: {
                    text: null
                }
		    },
		    yAxis: {
		        title: {
		            text: ''
		        },
		        labels: {
                    format: '{value} %'
                }
		    },
		    tooltip: {
		        shared: true,
		        formatter:function(){
		            return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>CPU利用率：<b>' + this.y+'%</b>';
		        }
		    },
		    legend: {
		        enabled: false
		    },
		    plotOptions: {
		        area: {
		            fillColor: {
		                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1},
		                stops: [
		                    [0, "#00B6E7"],
		                    [1, Highcharts.Color("#00B6E7").setOpacity(0).get('rgba')]
		                ]
		            },
		            lineWidth: 1,
		            marker: {
		                enabled: false
		            },
		            shadow: false,
		            states: {
		                hover: {
		                    lineWidth: 1
		                }
		            },
		        }
		    },

		    series: [{
		        type: 'area',
		        name: 'value',
		        data: series
		    }]
		});
	},
	drawMem:function(series){
		Highcharts.setOptions({
		    global: {
		        useUTC: false
		    }
		});
		
		$('#MemPused').highcharts({
		    credits: {
		        text: '',
		        href: '',
		        enabled: false 
		    },
		    chart: {
		        zoomType: 'x',
		        type:'line',
		        backgroundColor:"#EDF2F8"
		    },
		    colors:["#05B997"],
		    title: {
		        text: ''
		    },
		    xAxis: {
                labels: {  
                    formatter: function() {  
                        var vDate=moment(this.value);
                        return (dateRangePicker.MemPused.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                    }
                },
                title: {
                    text: null
                }
		    },
		    yAxis: {
		        title: {
		            text: ''
		        },
		        labels: {
                    format: '{value} %'
                }
		    },
		    tooltip: {
		        shared: true,
		        formatter:function(){
		            return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>内存利用率：<b>' + this.y+'%</b>';
		        }
		    },
		    legend: {
		        enabled: false
		    },
		    plotOptions: {
		        area: {
		            fillColor: {
		                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1},
		                stops: [
		                    [0, "#05B997"],
		                    [1, Highcharts.Color("#05B997").setOpacity(0).get('rgba')]
		                ]
		            },
		            lineWidth: 1,
		            marker: {
		                enabled: false
		            },
		            shadow: false,
		            states: {
		                hover: {
		                    lineWidth: 1
		                }
		            },
		        }
		    },

		    series: [{
		        type: 'area',
		        name: 'value',
		        data: series
		    }]
		});
	}
}

;(function(){
	dateRangePicker.Progress = Progress;
	dateRangePicker.CPUPused = CPUPused;
	dateRangePicker.MemPused = MemPused;
	dateRangePicker.apacheStatus = apacheStatus;
	dateRangePicker.Progress.getData();
	
	// Concurrent.getData('total');
	// Concurrent.bindEvent();
})();