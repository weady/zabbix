var AssetList = {
	getData:function () {
		//通过Zabbix服务发送请求
		ZabbixServer.sendAjaxRequest("host.get", null, function (data) {
		    //通过主机列表获取主机的各项数据
		    
		    var hosts = new Array();

		    for (var i = 0; i < data.result.length; i++) {
		    	 if(data.result[i].snmp_available === '0'){
		    	 	var host = new Object();
			    	 host.id = data.result[i].hostid;
			    	 host.name = data.result[i].name;

			    	 hosts.push(host);
		    	 }
		    }

		    AssetList.getDetail(hosts,function(detailData){});

		}, function(data){
		    //token不存在，返回登录
		    goToLogin();

		})
	},
	getDetail:function(hosts,callback){
		// 获取cpu核数
		// 获取磁盘数
		// CPU利用率
		// 内存总大小
		// 内存利用率
		
		var param0 = new Object();
		var hostids = new Array();

		for (var i = 0; i < hosts.length; i++) {
			hostids.push(hosts[i].id);
		}

		param0.hostids = hostids;
		param0.search = {
			"key_":"baseinfo[sys_info]"
		};


		// 获取磁盘数
		ZabbixServer.sendAjaxRequest("item.get", param0, function (assetdata) {

			// 组装数据到数组中
			var assetArray = assetdata.result;
			for (var i = 0; i < hosts.length; i++) {
				
				for (var j = 0; j < assetArray.length; j++) {
					
					if(hosts[i].id == assetArray[j].hostid){
						hosts[i].model = assetArray[j].lastvalue.split('|')[0];
						hosts[i].os = assetArray[j].lastvalue.split('|')[1];
						hosts[i].remark = assetArray[j].lastvalue.split('|')[2];
					}

				}

			}

			AssetList.addDom(hosts);

		}, function(data){
		    //token不存在，返回登录
		    goToLogin();

		});
	},
	addDom:function(hosts){	
		// 清空
		var $streamList = $('#streamList');

		$streamList.find('tobdy tr').remove();
		var dom ='';
		for (var i = 0; i < hosts.length; i++) {
			dom +='<tr>' +
	            '<td scope="row">'+GlobalUtil.getLineNumber(i+1)+'</td>' +
	            '<td>'+hosts[i].name+'</td>' +
	            '<td>'+hosts[i].model+'</td>' +
	            '<td>'+hosts[i].os+'</td>' +
	            '<td>'+hosts[i].remark+'</td>' +
	        '</tr>';
		}

		$streamList.find('tbody').append(dom);
	}
}

;(function(){
	AssetList.getData();
})();