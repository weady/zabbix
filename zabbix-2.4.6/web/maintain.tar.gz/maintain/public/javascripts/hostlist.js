var flag = window.location.search.split('=')[1];

var HostList = {
	getData:function () {
		//通过Zabbix服务发送请求

		ZabbixServer.sendAjaxRequest("host.get", null, function (data) {
		    //通过主机列表获取主机的各项数据
		    
		    var hosts = new Array();

		    for (var i = 0; i < data.result.length; i++) {
		    	 if(data.result[i].snmp_available === '0'){
		    	 	var host = new Object();
		    	 	host.id = data.result[i].hostid;
		    	 	host.name = data.result[i].name;
			    	if(data.result[i].available =='1'){
						host.status = '在线';
					}else{
						host.status = '离线';
					}
			    	hosts.push(host);
		    	 }
		    }

		    HostList.getDetail(hosts,function(detailData){});

		}, function(data){
		    //token不存在，返回登录
		    goToLogin();

		})
	},
	getDetail:function(hosts,callback){
		// 获取cpu核数
		// 获取磁盘数
		// CPU利用率
		// 内存总大小
		// 内存利用率
		
		var param0 = new Object();
		var hostids = new Array();

		for (var i = 0; i < hosts.length; i++) {
			hostids.push(hosts[i].id);
		}

		param0.hostids = hostids;
		param0.search = {
			"key_":"baseinfo[host_lists_info]"
		};
		ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
			
			var dataArray = data.result;
			
			for (var i = 0; i < hosts.length; i++) {
				
				for (var j = 0; j < dataArray.length; j++) {
					
					if(hosts[i].id == dataArray[j].hostid){
						hosts[i].disknum = dataArray[j].lastvalue.split('|')[0];
						hosts[i].cpunum = dataArray[j].lastvalue.split('|')[1];
						hosts[i].totalsize = dataArray[j].lastvalue.split('|')[2];
						hosts[i].cpuidle = dataArray[j].lastvalue.split('|')[3];
						hosts[i].pused = dataArray[j].lastvalue.split('|')[4];
					}

				}

			}
			HostList.addDom(hosts);
		});


	},
	addDom:function(hosts){	
		// 清空
		var $hostList = $('#hostList');

		$hostList.find('tbody').children().remove();
		var dom ='';
		var count = 0;
		for (var i = 0; i < hosts.length; i++) {
			if(flag == '0' ){
	    	 	if(hosts[i].status=='在线'){
	    	 		count++;
	 				dom +='<tr>' +
	 		            '<td scope="row">'+GlobalUtil.getLineNumber(count)+'</td>' +
	 		            '<td>'+hosts[i].name+'</td>' +
	 		            '<td>'+hosts[i].disknum+'</td>' +
	 		            '<td>'+hosts[i].cpunum+"&nbsp;&nbsp;"+'</td>' +
	 		            '<td>'+hosts[i].cpuidle+'%</td>' +
	 		            '<td>'+toFixed(hosts[i].totalsize,2)+'GB'+'</td>' +
	 		            '<td>'+toFixed(hosts[i].pused,2)+'%'+'</td>' +
	 		            '<td><span class="label '+(hosts[i].status=='在线'?'label-success':'label-danger')+'">'+hosts[i].status+'</span></td>' +
	 		            '<td><a class="label label-info" href="hostdetail_cpu.html?id='+hosts[i].id+'&name='+hosts[i].name+'">详情</a></td>' +
	 		        '</tr>';
	    	 	}
	    	 }else if(flag == '1'){
	    	 	if(hosts[i].status=='离线'){
	    	 		count++;
	    	 		dom +='<tr>' +
 			            '<td scope="row">'+GlobalUtil.getLineNumber(count)+'</td>' +
 			            '<td>'+hosts[i].name+'</td>' +
 			            '<td>'+hosts[i].disknum+'</td>' +
 			            '<td>'+hosts[i].cpunum+"&nbsp;&nbsp;"+'</td>' +
 			            '<td>'+hosts[i].cpuidle+'%</td>' +
	 		            '<td>'+toFixed(hosts[i].totalsize,2)+'GB'+'</td>' +
	 		            '<td>'+toFixed(hosts[i].pused,2)+'%'+'</td>' +
 			            '<td><span class="label '+(hosts[i].status=='在线'?'label-success':'label-danger')+'">'+hosts[i].status+'</span></td>' +
 			            '<td><a class="label label-info" href="hostdetail_cpu.html?id='+hosts[i].id+'&name='+hosts[i].name+'">详情</a></td>' +
 			        '</tr>';
	    	 	}
	    	 }else{
	    	 	count++;
	    	 	dom +='<tr>' +
		            '<td scope="row">'+GlobalUtil.getLineNumber(count)+'</td>' +
		            '<td>'+hosts[i].name+'</td>' +
		            '<td>'+hosts[i].disknum+'</td>' +
		            '<td>'+hosts[i].cpunum+"&nbsp;&nbsp;"+'</td>' +
		            '<td>'+hosts[i].cpuidle+'%</td>' +
 		            '<td>'+toFixed(hosts[i].totalsize,2)+'GB'+'</td>' +
 		            '<td>'+toFixed(hosts[i].pused,2)+'%'+'</td>' +
		            '<td><span class="label '+(hosts[i].status=='在线'?'label-success':'label-danger')+'">'+hosts[i].status+'</span></td>' +
		            '<td><a class="label label-info" href="hostdetail_cpu.html?id='+hosts[i].id+'&name='+hosts[i].name+'">详情</a></td>' +
		        '</tr>';
	    	 }
			
		}

		$hostList.find('tbody').append(dom);
	}
}

;(function(){
	HostList.getData();
})();