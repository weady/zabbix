var flag = window.location.search.split('=')[1];

var StreamList = {
	getData:function () {
		//通过Zabbix服务发送请求
		var param0 = new Object();
		param0.application = "频道录流监控";

		ZabbixServer.sendAjaxRequest("item.get", param0, function (data) {
		    //通过主机列表获取主机的各项数据
		    
		    var chnlList = new Array();

		    for (var i = 0; i < data.result.length; i++) {
		    	 if(data.result[i].state != 1){
		    	 	var chnl = new Object();
		    	 	chnl.name = data.result[i].name;
		    	 	chnl.value = data.result[i].lastvalue;
		    	 	chnl.clock = data.result[i].lastclock;
		    	 	chnl.itemid = data.result[i].itemid;

		    	 	if(flag == '0' ){
		    	 		if(chnl.value == '0'){
		    	 			chnlList.push(chnl);
		    	 		}
		    	 	}else if(flag == '1'){
		    	 		if(chnl.value != '0'){
		    	 			chnlList.push(chnl);
		    	 		}
		    	 	}else{
		    	 		chnlList.push(chnl);
		    	 	}
		    	 }
		    }
		    StreamList.addDom(chnlList);

		    $('#chnlname').html(chnlList[0].name+"录流曲线图");
		    dateRangePicker.StreamDetail.getData(chnlList[0].itemid);

		}, function(data){
		    //token不存在，返回登录
		    goToLogin();

		})
	},
	getDetail:function(hosts,callback){
		
		var param0 = new Object();
		var hostids = new Array();

		for (var i = 0; i < hosts.length; i++) {
			hostids.push(hosts[i].id);
		}

		param0.hostids = hostids;
		param0.search = {
			"key_":"baseinfo[sys_info]"  
		};


		// 获取磁盘数
		ZabbixServer.sendAjaxRequest("item.get", param0, function (assetdata) {

			// 组装数据到数组中
			var assetArray = assetdata.result;
			for (var i = 0; i < hosts.length; i++) {
				
				for (var j = 0; j < assetArray.length; j++) {
					
					if(hosts[i].id == assetArray[j].hostid){
						hosts[i].model = assetArray[j].lastvalue.split('|')[0];
						hosts[i].os = assetArray[j].lastvalue.split('|')[1];
						hosts[i].remark = assetArray[j].lastvalue.split('|')[2];
					}

				}

			}

			StreamList.addDom(hosts);

		}, function(data){
		    //token不存在，返回登录
		    goToLogin();

		});
	},
	addDom:function(chnlList){	
		// 清空
		var $streamList = $('#streamList');

		$streamList.find('tobdy tr').remove();
		var dom ='';
		for (var i = 0; i < chnlList.length; i++) {
			var domclass = "";
			if(chnlList[i].name.indexOf('_') != -1){
				chnlList[i].name = chnlList[i].name.substring(0,chnlList[i].name.indexOf('_'))+'多码率';
			}

			if(i == 0){
				domclass = "active"
			}

			dom +='<tr class="'+(chnlList[i].value =='0'?'danger':'') +domclass+'" data-itemid="'+chnlList[i].itemid+'">' +
	            '<td scope="row">'+GlobalUtil.getLineNumber(i+1)+'</td>' +
	            '<td>'+chnlList[i].name+'</td>' +
	            '<td>'+(chnlList[i].clock =='0'?'异常':moment(chnlList[i].clock*1000).format('YYYY年MM月DD日 HH:mm'))+'</td>' +
	            '<td class="'+(chnlList[i].value =='0'?'abnormal':'normal') +'">'+(chnlList[i].value =='0'?'异常':'正常')+'</td>' +
	            // '<td>'+(chnlList[i].value == '0'?'':'<a href="streamdetail.html?itemid='+chnlList[i].itemid+'">图表</a>')+'</td>' +
	        '</tr>';
			
		}

		$streamList.find('tbody').append(dom);

		StreamList.bindEvent();
	},
	bindEvent:function () {
		$('#streamList').off('click','tbody tr');
		$('#streamList').on('click','tbody tr',function(){
			var $this = $(this);

			$('#streamList').find('tr').removeClass('active');

			$this.addClass('active');

			var itemid = $(this).data('itemid');
				chnlname = $(this).find('td').eq(1).html();

			$('#chnlname').html(chnlname+"录流曲线图");
		    
		    dateRangePicker.StreamDetail.getData(itemid);
		});
	}
}

var StreamDetail = {
	getData: function(itemid){
        dateRangePicker.argsCache("StreamDetail", { itemid: itemid });
        itemid = this.argsCache.itemid;

        var _this = this;
        dateRangePicker.init("StreamDetail");

		var param0 = new Object();
		param0.itemids = itemid;
		param0.time_from = _this.fromUnix || moment().add(-15,'minutes').format('X');
		param0.time_till = _this.toUnix || moment().format('X');

		ZabbixServer.sendAjaxRequest(_this.methodType + ".get", param0, function (data) {
		    //通过主机列表获取主机的各项数据
		    var datalist = data.result;
		    var series = new Array();

		    for (var i = 0; i < datalist.length; i++) {
		    	series.push([parseInt(datalist[i].clock) * 1000, parseInt(datalist[i].value || datalist[i].value_avg)]);
		    }

		    StreamDetail.render(series);
		}, function(data){
		    //token不存在，返回登录
		    goToLogin();

		})
	},
	render:function(series){
		Highcharts.setOptions({
            global: {
                useUTC: false
            }
        });
        
        $('#StreamDetail').highcharts({
            credits: {
                text: '',
                href: '',
                enabled: false 
            },
            chart: {
                zoomType: 'x',
                type:'line',
                backgroundColor:"#EDF2F8"
            },
            colors:["#00B8EA",'#F27D41'],
            title: {
                text: ''
            },
            xAxis: {
                labels: {  
                    formatter: function() {  
                        var vDate=moment(this.value);
                        return (dateRangePicker.StreamDetail.xAxisType === 1 ? vDate.format('HH:mm') : vDate.format('MM/DD'));  
                    }
                },
                title: {
                    text: null
                }
            },
            yAxis: {
                title: {
                    text: ''
                }
            },
            tooltip: {
                formatter:function(){
                    return moment(this.x).format('YYYY年MM月DD日 HH:mm:ss') + '<br/>'+this.series.name+':<b>' + GlobalUtil.getSize(this.y)+'</b>';
                }
            },
            legend: {
                enabled: false
            },
            plotOptions: {
                line: {
                    lineWidth: 1,
                    marker: {
                        enabled: false
                    },
                    shadow: false,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    },
                }
            },

            series: [{
                type: 'line',
                name: '流入',
                data: series
            }]
        });
	}
}


var StreamDelete = {
	getData : function(){
		var param = {
			search:{
				'key_':'zabbix.data[get_del_channel_log]'
			}
		}

		var deleteData;
		ZabbixServer.sendAjaxRequest('item.get',param,function(data){
			for (var i = 0; i < data.result.length; i++) {
				if(data.result[i].templateid != '0'){
					deleteData = data.result[i].lastvalue.split('\n');
				}
			}
            if(!deleteData[0]) {
                $('#deletestreamhead').remove();
                $('#delete_table').children().remove();
                $('#delete_table').append('<div class="text-center alert" role="alert">无法获取当天的删流情况</div>');
                return false;
            }
            var dom = '';
            var tempArr;
            for (var i = 0; i < deleteData.length; i++) {

                tempArr = deleteData[i].split('|');

                dom += '<tr class="">' +
                        '<td style="width: 60px;">'+(i+1)+'</td>' +
                        '<td>'+tempArr[0]+'</td>' +
                        '<td>'+tempArr[1]+'</td>' +
                        '<td>'+tempArr[2]+'</td>' +
                    '</tr>';
            }

            $('#delete_table').children().remove();
            $('#delete_table').append(dom);

            var $header = $('#deletestreamhead').find('td');
            // 调整表头宽度
            $('#delete_table tr:first-child').find('td').each(function(index){
                
                var $this = $(this);

                // console.log(index);
                $header.eq(index).width($this.width()+'px');

            });
		});





	}
}


;(function(){
    dateRangePicker.StreamDetail = StreamDetail;
	StreamList.getData();
	StreamDelete.getData();
})();